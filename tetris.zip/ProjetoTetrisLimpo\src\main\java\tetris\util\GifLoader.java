package tetris.util;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.net.URI;
import java.net.URLConnection;

public class GifLoader {
    private static final String LOCAL_GIF_DIR = "src/main/resources/gifs";
    private static final String GAMEOVERGIF_LOCAL = "gameovergif.gif";
    private static final String HIGHSCOREGIF_LOCAL = "highscoregif.gif";

    // Try to load from local file first, then from URL
    public static ImageIcon loadGif(String localFileName, String urlString, int width, int height) {
        // Try local first
        ImageIcon icon = loadGifFromLocal(localFileName, width, height);
        if (icon != null) return icon;

        // Fall back to URL
        icon = loadGifFromUrl(urlString, width, height);
        if (icon != null) return icon;

        // Last resort: return null (caller will handle)
        return null;
    }

    private static ImageIcon loadGifFromLocal(String fileName, int width, int height) {
        try {
            File f = new File(LOCAL_GIF_DIR, fileName);
            if (!f.exists()) return null;

            ImageIcon icon = new ImageIcon(f.getAbsolutePath());
            if (icon.getImage() == null || icon.getIconWidth() <= 0) return null;

            // Resize if needed
            if (width > 0 && height > 0) {
                Image scaled = icon.getImage().getScaledInstance(width, height, Image.SCALE_DEFAULT);
                return new ImageIcon(scaled);
            }
            return icon;
        } catch (Exception e) {
            System.err.println("Erro ao carregar GIF local '" + fileName + "': " + e.getMessage());
            return null;
        }
    }

    public static ImageIcon loadGifFromUrl(String urlString, int width, int height) {
        try {
            URI uri = URI.create(urlString);
            URLConnection conn = uri.toURL().openConnection();
            conn.setConnectTimeout(3000);
            conn.setReadTimeout(3000);
            
            ImageIcon icon = new ImageIcon(uri.toURL());
            if (icon.getImage() == null || icon.getIconWidth() <= 0) return null;
            
            // Resize if needed
            if (width > 0 && height > 0) {
                Image scaled = icon.getImage().getScaledInstance(width, height, Image.SCALE_DEFAULT);
                return new ImageIcon(scaled);
            }
            return icon;
        } catch (Exception e) {
            System.err.println("Erro ao carregar GIF de URL: " + e.getMessage());
            return null;
        }
    }

    // Try to load from classpath (useful when resources are packaged in the jar)
    private static ImageIcon loadGifFromClasspath(String resourcePath, int width, int height) {
        try {
            java.net.URL res = Thread.currentThread().getContextClassLoader().getResource(resourcePath);
            if (res == null) return null;
            ImageIcon icon = new ImageIcon(res);
            if (icon.getImage() == null || icon.getIconWidth() <= 0) return null;
            if (width > 0 && height > 0) {
                Image scaled = icon.getImage().getScaledInstance(width, height, Image.SCALE_DEFAULT);
                return new ImageIcon(scaled);
            }
            return icon;
        } catch (Exception e) {
            System.err.println("Erro ao carregar GIF do classpath: " + e.getMessage());
            return null;
        }
    }

    public static ImageIcon getGameOverGif() {
        // Cellbit laughing GIF - try local first, then URL
        ImageIcon icon = loadGif(GAMEOVERGIF_LOCAL, "https://media.tenor.com/qzZT5n_pG2kAAAAM/cellbit-cat.gif", 300, 300);
        if (icon != null) return icon;
        // try loading from classpath
        return loadGifFromClasspath("gifs/" + GAMEOVERGIF_LOCAL, 300, 300);
    }

    public static ImageIcon getHighScoreGif() {
        // Cellbit poggers GIF - try local first, then URL
        ImageIcon icon = loadGif(HIGHSCOREGIF_LOCAL, "https://media.tenor.com/CjISuqLbCfYAAAAM/cellbit-poggers.gif", 300, 300);
        if (icon != null) return icon;
        return loadGifFromClasspath("gifs/" + HIGHSCOREGIF_LOCAL, 300, 300);
    }
}
