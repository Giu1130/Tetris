package tetris.ui;

import tetris.util.AuthManager;

import javax.swing.*;
import java.awt.*;

public class LoginDialog extends JDialog {
    private final AuthManager auth;
    private JTextField userField;
    private JPasswordField passField;
    private String username = null;
    private boolean confirmed = false;

    public LoginDialog(JFrame parent, AuthManager auth) {
        super(parent, "Login - TETRIS", true);
        this.auth = auth;
        setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
        setResizable(false);
        initComponents();
        setLocationRelativeTo(parent);
    }

    private void initComponents() {
        JPanel main = new JPanel();
        main.setBackground(TetrisColors.getBgDark());
        main.setLayout(new BoxLayout(main, BoxLayout.Y_AXIS));
        main.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Try to show logo above the login form
        javax.swing.ImageIcon logo = tetris.util.ImageLoader.getTetrisLogo();
        if (logo != null) {
            // Scale down the logo to fit better in the dialog
            Image scaledImage = logo.getImage().getScaledInstance(300, 150, Image.SCALE_SMOOTH);
            ImageIcon scaledLogo = new ImageIcon(scaledImage);
            JLabel logoLabel = new JLabel(scaledLogo);
            logoLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
            main.add(logoLabel);
            main.add(Box.createVerticalStrut(15));
        } else {
            JLabel title = new JLabel("Login");
            title.setFont(TetrisColors.getTitleFont());
            title.setForeground(TetrisColors.getAccent());
            title.setAlignmentX(Component.CENTER_ALIGNMENT);
            main.add(title);
            main.add(Box.createVerticalStrut(10));
        }

        userField = new JTextField(20);
    userField.setMaximumSize(new Dimension(460, 55));
    userField.setAlignmentX(Component.CENTER_ALIGNMENT);
    userField.setFont(TetrisColors.getGameFont());
    userField.setBorder(BorderFactory.createTitledBorder("Usuário"));
        main.add(userField);
        main.add(Box.createVerticalStrut(10));

    passField = new JPasswordField(20);
    passField.setMaximumSize(new Dimension(460, 55));
    passField.setAlignmentX(Component.CENTER_ALIGNMENT);
    passField.setFont(TetrisColors.getGameFont());
    passField.setBorder(BorderFactory.createTitledBorder("Senha"));
        main.add(passField);
        main.add(Box.createVerticalStrut(15));

        JPanel btns = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        btns.setBackground(TetrisColors.getBgDark());

        JButton loginBtn = new JButton("Entrar");
        loginBtn.setBackground(TetrisColors.getAccent());
        loginBtn.setForeground(Color.WHITE);
        loginBtn.addActionListener(e -> onLogin());

        JButton registerBtn = new JButton("Registrar");
        registerBtn.setBackground(new Color(0x4CAF50));
        registerBtn.setForeground(Color.WHITE);
        registerBtn.addActionListener(e -> onRegister());

        JButton exitBtn = new JButton("Sair");
        exitBtn.setBackground(new Color(0x777777));
        exitBtn.setForeground(Color.WHITE);
        exitBtn.addActionListener(e -> onExit());

        btns.add(loginBtn);
        btns.add(registerBtn);
        btns.add(exitBtn);

        main.add(btns);
        main.add(Box.createVerticalGlue());

    setContentPane(main);
    // Make login dialog larger so logo and fields fit comfortably
    setSize(680, 550);
    setPreferredSize(new Dimension(680, 550));

        userField.requestFocusInWindow();
    }

    private void onLogin() {
        String user = userField.getText().trim();
        String pass = new String(passField.getPassword());
        if (user.isEmpty() || pass.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Informe usuário e senha.", "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (auth.authenticate(user, pass)) {
            this.username = user;
            this.confirmed = true;
            setVisible(false);
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Usuário ou senha inválidos.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void onRegister() {
        RegistrationDialog rd = new RegistrationDialog((JFrame) getParent(), auth);
        rd.setVisible(true);
    }

    private void onExit() {
        this.username = null;
        this.confirmed = false;
        setVisible(false);
        dispose();
    }

    public String getUsername() { return username; }
    public boolean isConfirmed() { return confirmed; }
}
