package tetris.ui;

import java.awt.*;
import java.util.*;

public class TetrisTheme {
    public enum ThemeName {
        CLASSIC("Clássico"), NEON("Neon"), DARK("Escuro"), RETRO("Retrô");
        
        public final String displayName;
        ThemeName(String displayName) {
            this.displayName = displayName;
        }
    }

    public Color bgDark;
    public Color bgMedium;
    public Color accent;
    public Color textPrimary;
    public Color textSecondary;
    public Color gridLine;
    public Color cyan;
    public Color yellow;
    public Color purple;
    public Color green;
    public Color red;
    public Color blue;
    public Color orange;

    private static final Map<ThemeName, TetrisTheme> themes = new HashMap<>();
    private static TetrisTheme currentTheme;

    static {
        themes.put(ThemeName.CLASSIC, createClassicTheme());
        themes.put(ThemeName.NEON, createNeonTheme());
        themes.put(ThemeName.DARK, createDarkTheme());
        themes.put(ThemeName.RETRO, createRetroTheme());
        currentTheme = themes.get(ThemeName.CLASSIC);
    }

    private static TetrisTheme createClassicTheme() {
        TetrisTheme t = new TetrisTheme();
        t.bgDark = new Color(0x1a1a2e);
        t.bgMedium = new Color(0x2d2d44);
        t.accent = new Color(0xff4444);
        t.textPrimary = new Color(0xffffff);
        t.textSecondary = new Color(0xaaaaaa);
        t.gridLine = new Color(0x333333);
        t.cyan = new Color(0x00e5ff);
        t.yellow = new Color(0xffff00);
        t.purple = new Color(0xff00ff);
        t.green = new Color(0x00ff00);
        t.red = new Color(0xff0000);
        t.blue = new Color(0x0066ff);
        t.orange = new Color(0xff9900);
        return t;
    }

    private static TetrisTheme createNeonTheme() {
        TetrisTheme t = new TetrisTheme();
        t.bgDark = new Color(0x0a0e27);
        t.bgMedium = new Color(0x1a1a3e);
        t.accent = new Color(0xff00ff);
        t.textPrimary = new Color(0x00ffff);
        t.textSecondary = new Color(0x00aa88);
        t.gridLine = new Color(0x004422);
        t.cyan = new Color(0x00ffff);
        t.yellow = new Color(0xffff00);
        t.purple = new Color(0xff00ff);
        t.green = new Color(0x00ff00);
        t.red = new Color(0xff0066);
        t.blue = new Color(0x0099ff);
        t.orange = new Color(0xff6600);
        return t;
    }

    private static TetrisTheme createDarkTheme() {
        TetrisTheme t = new TetrisTheme();
        t.bgDark = new Color(0x1a1a1a);
        t.bgMedium = new Color(0x2d2d2d);
        t.accent = new Color(0x00cc00);
        t.textPrimary = new Color(0xe0e0e0);
        t.textSecondary = new Color(0x808080);
        t.gridLine = new Color(0x222222);
        t.cyan = new Color(0x00cccc);
        t.yellow = new Color(0xcccc00);
        t.purple = new Color(0xcc00cc);
        t.green = new Color(0x00cc00);
        t.red = new Color(0xcc0000);
        t.blue = new Color(0x0066cc);
        t.orange = new Color(0xcc7700);
        return t;
    }

    private static TetrisTheme createRetroTheme() {
        TetrisTheme t = new TetrisTheme();
        t.bgDark = new Color(0x2c3e50);
        t.bgMedium = new Color(0x34495e);
        t.accent = new Color(0xe74c3c);
        t.textPrimary = new Color(0xecf0f1);
        t.textSecondary = new Color(0x95a5a6);
        t.gridLine = new Color(0x444444);
        t.cyan = new Color(0x1abc9c);
        t.yellow = new Color(0xf1c40f);
        t.purple = new Color(0x9b59b6);
        t.green = new Color(0x27ae60);
        t.red = new Color(0xe74c3c);
        t.blue = new Color(0x3498db);
        t.orange = new Color(0xe67e22);
        return t;
    }

    public static void setTheme(ThemeName name) {
        if (themes.containsKey(name)) {
            currentTheme = themes.get(name);
        }
    }

    public static TetrisTheme getCurrent() {
        return currentTheme;
    }

    public static ThemeName[] getAllThemes() {
        return ThemeName.values();
    }

    public static Color getColor(String name) {
        return switch(name.toLowerCase()) {
            case "bgdark" -> currentTheme.bgDark;
            case "bgmedium" -> currentTheme.bgMedium;
            case "accent" -> currentTheme.accent;
            case "textprimary" -> currentTheme.textPrimary;
            case "textsecondary" -> currentTheme.textSecondary;
            case "cyan" -> currentTheme.cyan;
            case "yellow" -> currentTheme.yellow;
            case "purple" -> currentTheme.purple;
            case "green" -> currentTheme.green;
            case "red" -> currentTheme.red;
            case "blue" -> currentTheme.blue;
            case "orange" -> currentTheme.orange;
            default -> currentTheme.textPrimary;
        };
    }
}
