package tetris.domain;

import java.util.Arrays;

public class Tabuleiro {
    public static final int LARGURA = 10;
    public static final int ALTURA = 20;
    private final boolean[][] grid = new boolean[ALTURA][LARGURA];

    public boolean[][] getGrid(){ return grid; }

    public boolean posicaoValida(Tetromino t){
        boolean[][] f = t.getForma();
        Posicao p = t.getPos();
        for(int r=0;r<f.length;r++) for(int c=0;c<f[r].length;c++) {
            if(f[r][c]){
                int x = p.x() + c;
                int y = p.y() + r;
                if(x < 0 || x >= LARGURA || y >= ALTURA) return false;
                if(y >= 0 && grid[y][x]) return false;
            }
        }
        return true;
    }

    public void fixarPeca(Tetromino t){
        boolean[][] f = t.getForma();
        Posicao p = t.getPos();
        for(int r=0;r<f.length;r++) for(int c=0;c<f[r].length;c++) {
            if(f[r][c]){
                int x = p.x()+c;
                int y = p.y()+r;
                if(y>=0 && y<ALTURA && x>=0 && x<LARGURA) grid[y][x] = true;
            }
        }
    }

    public int eliminarLinhasCompletas(){
        int removidas = 0;
        for(int y=ALTURA-1;y>=0;y--){
            boolean completa = true;
            for(int x=0;x<LARGURA;x++) if(!grid[y][x]) { completa = false; break; }
            if(completa){
                for(int i=y;i>0;i--) System.arraycopy(grid[i-1],0,grid[i],0,LARGURA);
                Arrays.fill(grid[0], false);
                removidas++; y++;
            }
        }
        return removidas;
    }
}
