# Script para colocar imagens/GIFs enviados como "attachments" nas pastas do projeto
# Uso:
# 1) Salve os arquivos anexados (tetris_logo.png, gameovergif.gif, highscoregif.gif) em uma pasta local (ex: C:\Users\Giulia\Downloads\attachments)
# 2) Execute este script passando o caminho da pasta como parâmetro:
#    .\place-attachments.ps1 -SourceDir "C:\Users\Giulia\Downloads\attachments"
# 3) O script copiará os arquivos para src\main\resources e src\main\resources\gifs

param(
    [Parameter(Mandatory=$false)]
    [string]$SourceDir = "attachments"
)

$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$targetResources = Join-Path $projectRoot "src\main\resources"
$targetGifs = Join-Path $targetResources "gifs"

# Criar pastas se não existirem
if (!(Test-Path $targetResources)) { New-Item -ItemType Directory -Force -Path $targetResources | Out-Null }
if (!(Test-Path $targetGifs)) { New-Item -ItemType Directory -Force -Path $targetGifs | Out-Null }

Write-Host "Projeto: $projectRoot"
Write-Host "Fonte: $SourceDir"
Write-Host "Destino resources: $targetResources"
Write-Host "Destino gifs: $targetGifs"

$filesToPlace = @(
    @{ name = "tetris_logo.png"; dest = $targetResources },
    @{ name = "gameovergif.gif"; dest = $targetGifs },
    @{ name = "highscoregif.gif"; dest = $targetGifs }
)

foreach ($f in $filesToPlace) {
    $src = Join-Path $SourceDir $($f.name)
    $dst = Join-Path $($f.dest) $($f.name)
    if (Test-Path $src) {
        Copy-Item -Force -Path $src -Destination $dst
        Write-Host "✓ Copiado: $($f.name) -> $dst" -ForegroundColor Green
    } else {
        Write-Host "✗ Não encontrado: $src" -ForegroundColor Yellow
    }
}

Write-Host "\nVerifique se os arquivos apareceram em:"
Write-Host "  $targetResources"
Write-Host "  $targetGifs\n"
Write-Host "Se os arquivos não estiverem localmente, você pode usar download-gifs.ps1 para baixar do Tenor (se tiver internet)."