# 🎬 COMO ADICIONAR OS GIFS DO CELLBIT

## ⚠️ Problema Atual
Os GIFs estão sendo carregados de URLs da internet (Tenor), mas às vezes não funcionam por:
- Falta de conexão
- URL bloqueada/indisponível
- Timeout de rede

## ✅ Solução: Adicionar GIFs Locais

O sistema foi atualizado para:
1. **Tentar carregar GIFs locais primeiro** ✓
2. Se não encontrar, tenta URL da internet ✓
3. Se falhar, mostra fallback (ícone + texto) ✓

---

## 📁 Estrutura de Pastas

```
ProjetoTetrisLimpo/
├── src/
│   └── main/
│       └── resources/
│           └── gifs/                    ← CRIAR ESTE DIRETÓRIO
│               ├── gameovergif.gif      ← GIF quando perde
│               └── highscoregif.gif     ← GIF quando melhora score
├── pom.xml
└── ...
```

---

## 🚀 Passo a Passo

### 1️⃣ Criar a Pasta de GIFs

```powershell
# No PowerShell, dentro do projeto:
mkdir -Force "src\main\resources\gifs"
```

### 2️⃣ Adicionar os GIFs

**Opção A: Baixar da Internet**

Abra seu navegador e baixe:
- **gameovergif.gif** → https://media.tenor.com/qzZT5n_pG2kAAAAM/cellbit-cat.gif
- **highscoregif.gif** → https://media.tenor.com/CjISuqLbCfYAAAAM/cellbit-poggers.gif

Salve em: `src\main\resources\gifs\`

**Opção B: Usar Outros GIFs do Cellbit**

Procure no Google/Tenor por:
- "cellbit gif" (para qualquer gif do cellbit)
- Renomei para `gameovergif.gif` e `highscoregif.gif`

### 3️⃣ Verificar se Ficou Certo

```powershell
# Listar arquivos
Get-ChildItem "src\main\resources\gifs\" -File
```

Deve mostrar:
```
    Directory: C:\Users\Giulia Barros\Desktop\ProjetoTetrisLimpo\src\main\resources\gifs

Mode  Name
----  ----
-a--- gameovergif.gif
-a--- highscoregif.gif
```

### 4️⃣ Recompilar e Executar

```powershell
cd "C:\Users\Giulia Barros\Desktop\ProjetoTetrisLimpo"

# Limpar build anterior
mvn clean -q

# Recompilar
mvn -DskipTests package -q

# Executar
mvn exec:java
```

---

## 🎬 Resultado Esperado

Quando você clicar em **"Parar & Registrar"** ou **Game Over**:

✅ Se os GIFs locais existem:
- Mostra o GIF do Cellbit (300x300px)

✅ Se os GIFs locais não existem, mas tem internet:
- Tenta carregar da URL do Tenor

⚠️ Se tudo falhar:
- Mostra ícone do app + mensagem "(GIF indisponível)"

---

## 🔍 Checklist Final

- [ ] Pasta `src/main/resources/gifs/` criada
- [ ] `gameovergif.gif` dentro dela
- [ ] `highscoregif.gif` dentro dela
- [ ] Projeto recompilado (`mvn clean package`)
- [ ] Testado: cliquei em "Parar" e o GIF apareceu ✓

---

## 💡 Dicas

### Redimensionar GIFs (se quiser)
Se os GIFs forem muito grandes/pequenos, a código automaticamente redimensiona para 300x300px.
Não precisa fazer nada!

### Usar GIFs Diferentes
Quer usar outros GIFs? Basta:
1. Renomear para `gameovergif.gif` ou `highscoregif.gif`
2. Colocar em `src/main/resources/gifs/`
3. Recompilar

### Remover Timeout
Se a conexão de internet é muito lenta, o timeout é de 3 segundos.
Para aumentar, edite `GifLoader.java` linha ~31-32 (mudar 3000 para 5000 ou mais).

---

## ❌ Se Não Funcionar

1. Verifique o console para mensagens de erro
2. Confirme que o arquivo é `.gif` (não `.jpg` ou `.png`)
3. Tente com um GIF menor/diferente
4. Abra uma issue com os erros do console

