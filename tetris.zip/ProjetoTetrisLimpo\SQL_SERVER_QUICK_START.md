# ⚡ TETRIS - QUICK START COM SQL SERVER

## 🚀 Instalação Rápida (5 minutos)

### Opção A: Com Docker (Mais fácil)

```powershell
# 1. Abrir PowerShell como ADMINISTRADOR

# 2. Iniciar SQL Server em Docker
docker run -e "ACCEPT_EULA=Y" -e "SA_PASSWORD=YourPassword123!" `
  -p 1433:1433 `
  --name sqlserver-tetris `
  -d mcr.microsoft.com/mssql/server:latest

# 3. Aguarde 30 segundos para SQL Server iniciar
Start-Sleep -Seconds 30

# 4. Criar banco de dados (copie e cole no PowerShell)
$sqlScript = @"
CREATE DATABASE TetrisGame;
GO
USE TetrisGame;
GO
CREATE TABLE usuarios (
    id INT PRIMARY KEY IDENTITY(1,1),
    username NVARCHAR(100) UNIQUE NOT NULL,
    password NVARCHAR(256) NOT NULL,
    data_criacao DATETIME DEFAULT GETDATE()
);
CREATE TABLE ranking (
    id INT PRIMARY KEY IDENTITY(1,1),
    usuario_id INT NOT NULL,
    pontuacao INT NOT NULL,
    nivel INT NOT NULL,
    linhas INT NOT NULL,
    dificuldade NVARCHAR(50) NOT NULL,
    data_partida DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);
"@

$sqlScript | sqlcmd -S localhost -U sa -P "YourPassword123!" -d master
```

### Opção B: Script Automático

```powershell
# 1. Abrir PowerShell como ADMINISTRADOR
# 2. Navegue até a pasta do projeto
Set-Location "c:\Users\Giulia Barros\Desktop\ProjetoTetrisLimpo"

# 3. Execute o script
.\setup-sqlserver.ps1
```

---

## ▶️ Executar o Jogo

```powershell
# No diretório do projeto
mvn -DskipTests compile
mvn -DskipTests exec:java
```

**Pronto!** 🎮 A janela do Tetris vai abrir!

---

## ✅ Se aparecer este erro:

```
✗ Não foi possível conectar ao SQL Server: ...
  Usando fallback para arquivo de usuários (users.txt)
```

**Não se preocupe!** O jogo vai funcionar normalmente usando `users.txt` como fallback. SQL Server é opcional.

---

## 📊 Tabelas do Banco

### `usuarios`
```
id        | username | password (hash SHA-256)        | data_criacao
----------|----------|--------------------------------|----------
1         | julia    | a1b2c3d4e5f6... (hash)         | 2025-01-12
2         | professor| x9y8z7w6v5u4... (hash)         | 2025-01-12
```

### `ranking`
```
id | usuario_id | pontuacao | nivel | linhas | dificuldade | data_partida
---|------------|-----------|-------|--------|-------------|----------
1  | 1          | 5000      | 10    | 25     | Normal      | 2025-01-12
2  | 1          | 8500      | 15    | 40     | Difícil     | 2025-01-12
```

---

## 🎮 Controles

| Ação | Tecla |
|------|-------|
| Mover | ← → |
| Descer | ↓ |
| Hard Drop | ESPAÇO |
| Rotacionar | X / Z |
| Hold | C |
| Pausar | P |
| Reiniciar | R |

---

## 📋 Checklist para Apresentação

- [ ] SQL Server está rodando
- [ ] Banco `TetrisGame` foi criado
- [ ] App compila sem erros: `mvn -DskipTests compile`
- [ ] App inicia: `mvn -DskipTests exec:java`
- [ ] Consegui fazer login
- [ ] Consegui jogar
- [ ] Consegui ver ranking
- [ ] Consegui exportar (CSV/HTML)

---

## 🆘 Problemas Comuns

**Erro: "Connection refused"**
- SQL Server não está rodando
- Se usou Docker: `docker start sqlserver-tetris`
- Se usou instalação local: iniciar serviço SQL Server

**Erro: "Login failed"**
- Verificar usuário/senha em `DatabaseManager.java`
- Padrão: usuário `sa`, senha `YourPassword123!`

**App funciona mas sem dados no DB**
- Verifique que SQL Server realmente conectou (mensagem ✓ na inicialização)
- Se não conectar, usa fallback `users.txt`

**Onde está o arquivo do banco?**
- **Docker:** Dentro do container (persiste em volume)
- **Local:** C:\Program Files\Microsoft SQL Server\

---

## 📱 Alternativas se não tiver SQL Server

**Opção 1: Usar MySQL**
- Instalar MySQL: mysql.com
- Mudar `DatabaseManager.java` URL para MySQL
- Adaptar sintaxe SQL

**Opção 2: Continuar com SQLite**
- Revert `DatabaseManager.java` para SQLite
- Alterar: `private static final String DB_URL = "jdbc:sqlite:tetris_game.db";`

**Opção 3: Apenas arquivo (users.txt)**
- App já tem fallback automático
- Sem SQL Server, usa arquivo local
- Tudo continua funcionando!

---

## 📚 Mais Informações

- Veja `GUIA_SQL_SERVER.md` para configuração detalhada
- Veja `RESUMO_IMPLEMENTACAO.md` para arquitetura completa
- Veja `COMO_EXECUTAR.md` para controles do jogo

---

**Boa sorte na apresentação! 🎓🎮**

