package tetris.domain;

import java.awt.Color;
import java.util.Random;

public class TetrominoFactory {
    private static final Random R = new Random();
    public static Tetromino criarAleatorio(int spawnX, int spawnY){
        int v = R.nextInt(7);
        Posicao p = new Posicao(spawnX, spawnY);
        return switch(v){
            case 0 -> criarI(p);
            case 1 -> criarO(p);
            case 2 -> criarT(p);
            case 3 -> criarS(p);
            case 4 -> criarZ(p);
            case 5 -> criarJ(p);
            default -> criarL(p);
        };
    }
    private static Tetromino criarI(Posicao p){ return new Tetromino(new boolean[][]{{true,true,true,true}}, new Color(0x00FFFF), p); }
    private static Tetromino criarO(Posicao p){ return new Tetromino(new boolean[][]{{true,true},{true,true}}, new Color(0xFFFF00), p); }
    private static Tetromino criarT(Posicao p){ return new Tetromino(new boolean[][]{{false,true,false},{true,true,true}}, new Color(0x800080), p); }
    private static Tetromino criarS(Posicao p){ return new Tetromino(new boolean[][]{{false,true,true},{true,true,false}}, new Color(0x00FF00), p); }
    private static Tetromino criarZ(Posicao p){ return new Tetromino(new boolean[][]{{true,true,false},{false,true,true}}, new Color(0xFF0000), p); }
    private static Tetromino criarJ(Posicao p){ return new Tetromino(new boolean[][]{{true,false,false},{true,true,true}}, new Color(0x0000FF), p); }
    private static Tetromino criarL(Posicao p){ return new Tetromino(new boolean[][]{{false,false,true},{true,true,true}}, new Color(0xFFA500), p); }
}
