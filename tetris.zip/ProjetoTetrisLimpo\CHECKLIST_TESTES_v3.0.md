# 🧪 CHECKLIST DE TESTES - TETRIS v3.0

## 📋 GUIA DE TESTES

Execute o seguinte comando para iniciar:
```powershell
java -jar target/ProjetoTetrisLimpo-1.0-SNAPSHOT.jar
```

---

## ✅ SEÇÃO 1: TELA DE LOGIN

### Teste 1.1 - Logo Display
- [ ] Abre tela de login
- [ ] Se tiver `tetris_logo.png`: Mostra imagem colorida (250x150)
- [ ] Se não tiver: Mostra "TETRIS" em texto vermelho (Arial 48)
- [ ] Texto fica centralizado

### Teste 1.2 - Funcionalidade
- [ ] Pode digitar nome normalmente
- [ ] Botão "Começar" funciona (entra no jogo)
- [ ] Botão "Sair" fecha o app
- [ ] Pressionar ENTER também começa

### Teste 1.3 - Validação
- [ ] Nome em branco: Permite? (verificar)
- [ ] Nomes com caracteres especiais: Aceita
- [ ] Nomes longos: Aceita (trunca se necessário)

---

## ✅ SEÇÃO 2: GAMEPLAY - TECLADO

### Teste 2.1 - Movimentos Básicos
- [ ] **SETA ESQUERDA**: Peça move para ESQUERDA
- [ ] **SETA DIREITA**: Peça move para DIREITA  
- [ ] **SETA PARA BAIXO**: Soft drop (velocidade aumenta)
- [ ] **SETA PARA CIMA**: Rotaciona a peça
- [ ] **SPACE**: Hard drop (cai completamente)
- [ ] **C**: Hold (guarda peça)

### Teste 2.2 - Controles UI
- [ ] **P**: Pausa/Despausa o jogo
- [ ] **R**: Reinicia o jogo

---

## ✅ SEÇÃO 3: COMBO BOX BUG FIX (IMPORTANTE!)

### Teste 3.1 - Combobox Sem Bug
1. Jogo rodando normalmente
2. **Clique em "Dificuldade: [Normal ▼]"**
3. Combo abre
4. **Imediatamente tente apertar SETA ESQUERDA/DIREITA**
5. **RESULTADO ESPERADO**: 
   - ✅ Peça move ESQUERDA/DIREITA (NÃO o combo)
   - ✅ Jogo continua fluindo

**❌ SE FALHAR**:
- Combo absorve as setas
- Peça não responde
- Controle congelado

### Teste 3.2 - Trocar Dificuldade
- [ ] Abrir combo de dificuldade
- [ ] Escolher "Fácil" 
- [ ] **Verificar**: Peças caem MAIS LENTAMENTE
- [ ] Escolher "Difícil"
- [ ] **Verificar**: Peças caem MAIS RÁPIDO

### Teste 3.3 - Trocar Tema
- [ ] Abrir combo de tema
- [ ] Escolher "Neon"
- [ ] **Verificar**: Cores mudam para neon (mais vibrante)
- [ ] Escolher "Dark"
- [ ] **Verificar**: Cores mais escuras
- [ ] **Importante**: Teclado continua funcionando durante mudança

---

## ✅ SEÇÃO 4: GAME OVER - GIF E RANK DETECTION

### Teste 4.1 - Primeiro Jogo (PERDE)
1. Jogar até game over (não entre em Top 10)
2. Score baixo (ex: 100 pontos)
3. **RESULTADO ESPERADO**:
   - [ ] Título: "GAME OVER" (VERMELHO)
   - [ ] GIF: Cellbit SAD (tristinho/frustrado)
   - [ ] Não salva no ranking (se score é baixo)
   - [ ] Botão "OK" funciona

### Teste 4.2 - Novo Record (Top 10 Vazio)
1. Jogar conseguindo alto score
2. Score entra no top 10 (ex: 5000 pontos)
3. **RESULTADO ESPERADO**:
   - [ ] Título: "NOVO RECORD!" (OURO #FFD700)
   - [ ] GIF: Cellbit POGGERS (comemorando)
   - [ ] Salva no ranking automático
   - [ ] Botão "OK" funciona

### Teste 4.3 - Melhora Posição (Mesmo Jogador)
1. Jogar primeira vez: 5000 pontos (entra no top 10)
2. Novo jogo com MESMO NOME: 7000 pontos (melhora)
3. **RESULTADO ESPERADO**:
   - [ ] Título: "MELHOROU DE RANK!" (VERDE #00FF00)
   - [ ] GIF: Cellbit POGGERS (celebrando)
   - [ ] Atualiza ranking
   - [ ] Posição do ranking melhora

### Teste 4.4 - Mesma Posição (Sem Melhora)
1. Jogar primeira vez: 5000 pontos (top 10)
2. Novo jogo com MESMO NOME: 4000 pontos (piora)
3. **RESULTADO ESPERADO**:
   - [ ] Título: "GAME OVER" (VERMELHO)
   - [ ] GIF: Cellbit SAD
   - [ ] Não atualiza ranking (score é menor)

---

## ✅ SEÇÃO 5: HUD - SCORE PANEL

### Teste 5.1 - Exibição de Dados
- [ ] Pontuação atualiza em tempo real
- [ ] Nível mostra corretamente
- [ ] Linhas completas são contadas
- [ ] Tempo aumenta constantemente

### Teste 5.2 - Status
- [ ] Quando pausado: Mostra ">>> PAUSADO <<<"
- [ ] Quando retoma: Desaparece a mensagem

---

## ✅ SEÇÃO 6: BOTÃO "PARAR & REGISTRAR"

### Teste 6.1 - Funcionamento
1. Jogar normalmente
2. **Clique em "Parar & Registrar"** (botão laranja)
3. **RESULTADO ESPERADO**:
   - [ ] Jogo para imediatamente
   - [ ] Abre GameOverDialog (mesmo do game over)
   - [ ] Mostra stats da partida
   - [ ] Detecta corretamente se é melhoria de rank

### Teste 6.2 - Sem Perder Dados
- [ ] Score, Nível, Linhas são salvos corretamente
- [ ] Ranking é atualizado se necessário
- [ ] Depois de OK, pode reiniciar ou ver ranking

---

## ✅ SEÇÃO 7: RANKING PANEL

### Teste 7.1 - Exibição
- [ ] Botão "Ranking" funciona
- [ ] Abre painel com top 10
- [ ] Nomes aparecem formatados (20 caracteres)
- [ ] Scores aparecem com 6 dígitos

### Teste 7.2 - Atualização
- [ ] Após novo record, ranking atualiza
- [ ] Posições ficam corretas
- [ ] Placar mais novo fica em primeiro

---

## ✅ SEÇÃO 8: WINDOW TITLE

### Teste 8.1 - Nome do Jogador
- [ ] Título mostra: "TETRIS - [NomeDoJogador]"
- [ ] Exemplo: "TETRIS - Giulia"
- [ ] Mantém durante todo o jogo

### Teste 8.2 - Ícone da Janela
- [ ] Se tiver `tetris_icon.png`: Mostra imagem
- [ ] Se não tiver: Mostra ícone azul ciano
- [ ] Ícone aparece na barra de tarefas

---

## ✅ SEÇÃO 9: VISUAL 3D DAS PEÇAS

### Teste 9.1 - Aparência dos Blocos
- [ ] Cada bloco tem efeito 3D (beveled)
- [ ] Borda superior/esquerda mais clara
- [ ] Borda inferior/direita mais escura
- [ ] Parece "emerso" ou "inset" da tela

### Teste 9.2 - Peças Diferentes
- [ ] I-piece (azul): 3D visível
- [ ] O-piece (amarelo): 3D visível
- [ ] T-piece (roxo): 3D visível
- [ ] S/Z-pieces: 3D visível
- [ ] L/J-pieces: 3D visível

---

## 📊 RESUMO DE TESTES

| Área | Teste | Status | Notas |
|------|-------|--------|-------|
| Login | Logo PNG | ✅ | Ou fallback texto |
| Login | Entrada nome | ✅ | |
| Teclado | Setas | ✅ | **CRÍTICO** - Bug fix |
| Teclado | Rotação | ✅ | |
| Combo | Sem travar | ✅ | **CRÍTICO** |
| Game Over | GIF Poggers | ✅ | Top 10 |
| Game Over | GIF Sad | ✅ | Perdeu |
| Game Over | Título dinâmico | ✅ | 3 cores |
| Score | Atualização | ✅ | |
| Ranking | Atualização | ✅ | |
| Window | Título + Nome | ✅ | |
| Window | Ícone | ✅ | PNG ou fallback |
| Visual | Blocos 3D | ✅ | |

---

## 🎯 PRIORIDADE ALTA - Testes Críticos

**Execute estes testes PRIMEIRO:**

1. ✅ **Teste 3.1** - Combo Box sem bug (CRITICAL)
2. ✅ **Teste 4.2** - Novo Record GIF (CRITICAL)
3. ✅ **Teste 4.3** - Melhora de Rank GIF (CRITICAL)
4. ✅ **Teste 6.1** - Botão "Parar & Registrar" (HIGH)
5. ✅ **Teste 2.1** - Movimentos básicos (HIGH)

---

## 🚀 Build e Testes

```powershell
# Build
mvn clean package -DskipTests

# Executar
java -jar target/ProjetoTetrisLimpo-1.0-SNAPSHOT.jar

# Se houver erros, recompilar
mvn clean compile -DskipTests
```

---

## 📝 Notas de Teste

- **Emojis**: Removidos dos títulos (causa rendering estranho)
- **GIFs**: Carregam via URL (precisa internet)
- **Imagens PNG**: Opcionais (funcionam com fallback)
- **Font rendering**: Sem problemas com Arial/Courier New
- **Performance**: Deve rodar smooth 60 FPS

---

**Bom teste! 🎮✅**