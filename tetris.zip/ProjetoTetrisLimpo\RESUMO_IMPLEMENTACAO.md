# 📋 RESUMO COMPLETO - TETRIS Java 21 LTS

## 🎮 O que foi implementado

### 1. **NÚCLEO DO JOGO** (Pasta: `domain/`)
#### Lógica de Jogo
- **`Partida.java`** ⭐ - Gerencia toda a lógica do jogo
  - Controla peça atual, próxima peça e fila de 5 peças
  - Sistema de HOLD (segurar peça para depois)
  - Hard Drop (espaço), Soft Drop (seta para baixo)
  - Detecção de Game Over
  - Integração com Sistema de Pontuação

- **`Tabuleiro.java`** - Grid do jogo (10 colunas × 20 linhas)
  - Verificação de colisões e posições válidas
  - Eliminar linhas completas com lógica correta
  - Renderização do grid

- **`Tetromino.java`** - Representa as peças (I, O, T, S, Z, J, L)
  - Armazena forma (matrix booleana), cor e posição
  - Métodos de movimento (esquerda, direita, baixo, cima)
  - Rotação no sentido horário

- **`TetrominoFactory.java`** - Gerador de peças aleatórias
  - Cria cada tipo de Tetromino com cor correta
  - Spawn position padrão (x=4, y=-2)

- **`Posicao.java`** - Sistema de coordenadas (x, y)

- **`Jogador.java`** - Informações do jogador (nome)

- **`SistemaPontuacao.java`** - Cálculo de pontos
  - Linhas limpas
  - Soft Drop (1 ponto/célula)
  - Hard Drop (2 pontos/célula)
  - Multiplicador por dificuldade

---

### 2. **INTERFACE GRÁFICA** (Pasta: `ui/`)

#### Componentes Principais
- **`TelaPrincipal.java`** ⭐ - Janela principal
  - Integra todos os painéis (game, score, next, hold)
  - Gerenciador de timers (renderização, drop, clock)
  - Suporte a 4 dificuldades: Fácil, Normal, Difícil, Hardcore
  - Botões: Start, Ranking, Statistics, Pause, Restart
  - Seleção de dificuldade via ComboBox
  - Renderização em Swing com 60 FPS

- **`GamePanel.java`** - Painel de renderização do tabuleiro
  - Desenha blocos fixos em 3D
  - Desenha peça atual
  - Desenha "ghost piece" (previsão onde a peça vai cair)
  - Cores e bordas temáticas

- **`ScorePanel.java`** - Painel de placar
  - Mostra: pontuação, nível, linhas, tempo
  - Status (pausado, game over, etc)

- **`NextPiecePanel.java`** - Fila de próximas 5 peças
  - Renderiza as peças que virão a seguir

- **`HoldPanel.java`** - Painel da peça segurada
  - Mostra qual peça está "holded"

#### Dialogs (Janelas Modais)
- **`LoginDialog.java`** - Tela de LOGIN
  - Logo do Tetris no topo
  - Campos: Usuário e Senha
  - Botões: Login, Register
  - Tamanho: 680×550

- **`RegistrationDialog.java`** - Tela de REGISTRO
  - Cadastro de novo usuário
  - Validação de campos
  - Hashing SHA-256 da senha

- **`PlayerNameDialog.java`** - Diálogo para inserir nome do jogador

- **`GameOverDialog.java`** - Tela de Game Over
  - Mostra GIF diferente se surpassed record ou não
  - Exibe estatísticas: jogador, pontuação, nível, linhas
  - Integrado com banco de dados para detectar novo record

- **`RankingPanel.java`** - Tela do Top 10
  - Selector de dificuldade (Fácil, Normal, Difícil, Hardcore)
  - Mostra top 10 rankings por dificuldade
  - Atualização em tempo real

- **`StatisticsPanel.java`** - Dashboard de Estatísticas
  - Top 10 de todos os modos
  - Totais por dificuldade
  - Botões de exportação (CSV, HTML, Todos)

#### Tema e Cores
- **`TetrisTheme.java`** - Sistema de temas
  - Tema CLASSIC (padrão)
  - Cores dinâmicas para modo claro/escuro

- **`TetrisColors.java`** - Paleta de cores centralizada
  - Cores dos blocos
  - Cores da UI
  - Fontes padronizadas

---

### 3. **SISTEMA DE ENTRADA** (Pasta: `engine/`)

- **`InputHandler.java`** - Processamento de teclado
  - Seta esquerda/direita: Mover peça
  - Seta para baixo: Soft Drop
  - Espaço: Hard Drop
  - Z/X: Rotacionar
  - C: Hold
  - P: Pausar
  - R: Reiniciar

---

### 4. **PERSISTÊNCIA E BANCO DE DADOS** (Pasta: `util/`)

#### Autenticação e Usuários
- **`AuthManager.java`** ⭐ - Gerenciador de Login/Registro
  - **Modo RESILIENTE**: Tenta DB primeiro, cai para arquivo se DB indisponível
  - Hashing SHA-256 das senhas
  - Fallback para `users.txt` quando SQL não está disponível
  - Métodos:
    - `register(username, password)` - registra novo usuário
    - `authenticate(username, password)` - valida credenciais
    - `userExists(username)` - verifica se usuário existe

- **`DatabaseManager.java`** - Gerenciador do banco de dados SQLite
  - Conexão: `jdbc:sqlite:tetris_game.db` (arquivo local)
  - 2 tabelas principais:
    
    **TABELA: `usuarios`**
    ```
    id              (INTEGER PRIMARY KEY AUTOINCREMENT)
    username        (TEXT UNIQUE NOT NULL)
    password        (TEXT - hash SHA-256)
    data_criacao    (TIMESTAMP DEFAULT CURRENT_TIMESTAMP)
    ```
    
    **TABELA: `ranking`**
    ```
    id              (INTEGER PRIMARY KEY AUTOINCREMENT)
    usuario_id      (INTEGER - chave estrangeira → usuarios.id)
    pontuacao       (INTEGER)
    nivel           (INTEGER)
    linhas          (INTEGER)
    dificuldade     (TEXT - "Fácil", "Normal", "Difícil", "Hardcore")
    data_partida    (TIMESTAMP DEFAULT CURRENT_TIMESTAMP)
    ```
  
  - Métodos principais:
    - `init()` - inicializa conexão e cria tabelas
    - `addUser(username, password)` - insere novo usuário
    - `getUserPassword(username)` - recupera hash da senha
    - `addRanking(...)` - insere novo score
    - `getTop10(difficulty)` - top 10 por dificuldade

#### Utilitários
- **`Ranking.java`** - Gerenciador de rankings
  - `getTop10(difficulty)` - retorna top 10 de uma dificuldade
  - `addEntry(RankingEntry)` - adiciona nova entrada

- **`RankingEntry.java`** - Classe para armazenar entrada de ranking
  - playerName, score, level, lines, difficulty

- **`GifLoader.java`** - Carregador de GIFs
  - Tenta carregar de: recursos locais → URL → classpath
  - `getGameOverGif()` - GIF de game over triste
  - `getHighScoreGif()` - GIF de novo record (celebração)

- **`ImageLoader.java`** - Carregador de imagens
  - `getTetrisLogo()` - logo do Tetris para login
  - `getAppIcon()` - ícone da aplicação

- **`ExportManager.java`** - Exportação de dados
  - `exportRankingToCSV(difficulty, path)` - exporta para CSV
  - `exportRankingToHTML(difficulty, path)` - exporta para HTML
  - `exportAllDifficulties(outDir)` - exporta todos os modos

- **`AuthFileFallbackTest.java`** - Teste de resilência
  - Valida que AuthManager funciona sem DB

---

## 💾 BANCO DE DADOS - ONDE FICA?

### 📍 Localização do Banco de Dados

**Arquivo: `tetris_game.db`**

**Caminho completo:**
```
c:\Users\Giulia Barros\Desktop\ProjetoTetrisLimpo\tetris_game.db
```

**Tipo:** SQLite (arquivo único, sem servidor necessário)

### 🔧 Como funciona

1. **Quando você executa o app:**
   ```bash
   mvn -DskipTests exec:java
   ```
   - O `DatabaseManager.init()` é chamado pelo `AuthManager`
   - Se o arquivo `tetris_game.db` não existe → é criado automaticamente
   - As tabelas `usuarios` e `ranking` são criadas (se não existirem)
   - Conexão fica aberta durante toda a sessão

2. **Dados armazenados:**
   - **Usuários:** nome, senha (hasheada), data de criação
   - **Rankings:** usuário, pontuação, nível, linhas, dificuldade, data

3. **Sistema de fallback:**
   - Se o SQLite falhar → usa arquivo `users.txt` para login/registro
   - Arquivo `users.txt` fica no mesmo diretório do projeto

### 📊 Estrutura do Banco

```
tetris_game.db (arquivo SQLite)
├── Tabela: usuarios
│   ├── id (chave primária)
│   ├── username (único)
│   ├── password (hash SHA-256)
│   └── data_criacao
│
└── Tabela: ranking
    ├── id (chave primária)
    ├── usuario_id (referencia usuarios.id)
    ├── pontuacao
    ├── nivel
    ├── linhas
    ├── dificuldade ("Fácil", "Normal", "Difícil", "Hardcore")
    └── data_partida
```

### 🔍 Como visualizar o banco

Você pode usar qualquer ferramenta SQLite:
- **DB Browser for SQLite** (GUI)
- **SQLite3 CLI** no terminal:
  ```powershell
  sqlite3 "tetris_game.db"
  sqlite> SELECT * FROM usuarios;
  sqlite> SELECT * FROM ranking;
  ```

### ⚙️ Configuração no código

Arquivo: `DatabaseManager.java` (linha 5)
```java
private static final String DB_URL = "jdbc:sqlite:tetris_game.db";
```

Se você quiser mudar a localização, basta editar essa linha. Por exemplo:
- `jdbc:sqlite:./banco/tetris.db` - cria em pasta `banco/`
- `jdbc:sqlite:/tmp/tetris.db` - cria em `/tmp/`

---

## 🎯 Fluxo da Aplicação

```
1. INICIA → Main.java
   ↓
2. MOSTRA LoginDialog
   - Tenta autenticar
   - Se falhar, permite registrar novo usuário
   - AuthManager tenta DB primeiro, depois users.txt
   ↓
3. SE LOGIN OK → Carrega TelaPrincipal
   - Mostra tela de seleção de dificuldade
   - User clica "START"
   ↓
4. INICIA GamePanel
   - Renderiza tabuleiro (60 FPS)
   - Processa input (teclado)
   - Atualiza lógica de jogo
   ↓
5. GAME OVER → GameOverDialog
   - Verifica se foi novo record (consulta DB)
   - Mostra GIF apropriado
   - Salva resultado no ranking (ranking table)
   ↓
6. USER PODE:
   - Ver Ranking (Top 10 por dificuldade)
   - Ver Estatísticas (dashboard com CSV/HTML export)
   - Reiniciar jogo
   - Logout
```

---

## 🔐 Segurança

- **Senhas:** Hasheadas com SHA-256 (não são armazenadas em texto plano)
- **Autenticação:** Válida hash da senha, nunca a senha em texto
- **Banco:** SQLite local (sem servidor exposto)
- **Fallback:** Se DB indisponível, usa arquivo local `users.txt` com mesma segurança

---

## 📦 Dependências principais (pom.xml)

- **Java 21 LTS**
- **Swing** (interface gráfica)
- **SQLite JDBC** (`org.xerial:sqlite-jdbc`)
- **Maven** (build)

---

## 🎮 CONTROLES DO JOGO

| Ação | Tecla |
|------|-------|
| Mover esquerda | ← |
| Mover direita | → |
| Soft Drop | ↓ |
| Hard Drop | ESPAÇO |
| Rotacionar CW | X |
| Rotacionar CCW | Z |
| Hold (Segurar) | C |
| Pausar | P |
| Reiniciar | R |
| Ranking | Botão na UI |
| Estatísticas | Botão na UI |

---

## ✅ Status Final

- ✅ Jogo Tetris completo (com todas as mecânicas)
- ✅ UI bonita com tema personalizável
- ✅ Sistema de usuários com autenticação
- ✅ Rankings por dificuldade
- ✅ GIFs dinâmicos (celebração vs game over)
- ✅ Exportação de dados (CSV, HTML)
- ✅ **Resiliente**: funciona COM ou SEM banco de dados


