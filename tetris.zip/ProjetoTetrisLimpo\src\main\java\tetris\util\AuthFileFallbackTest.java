package tetris.util;

import java.io.File;

/**
 * Simple runner to test AuthManager file-fallback when DB is unavailable.
 * Run with: mvn -DskipTests exec:java -Dexec.mainClass=tetris.util.AuthFileFallbackTest
 */
public class AuthFileFallbackTest {
    public static void main(String[] args) {
        System.out.println("Auth file-fallback test starting...");

        // Remove existing test user from users.txt to get deterministic behavior
        File f = new File("users.txt");
        if (f.exists()) {
            System.out.println("Found existing users.txt (size=" + f.length() + "). Will append test entry.");
        }

        AuthManager auth = new AuthManager();

        // Simulate DB down by closing connection
        try {
            DatabaseManager.closeConnection();
            System.out.println("Database connection closed to simulate DB unavailability.");
        } catch (Exception e) {
            System.out.println("Failed to close DB connection: " + e.getMessage());
        }

        String user = "demo_user_cli";
        String pass = "senha123";

        boolean registered = auth.register(user, pass);
        System.out.println("register(" + user + ") -> " + registered);

        boolean authenticated = auth.authenticate(user, pass);
        System.out.println("authenticate(" + user + ") -> " + authenticated);

        if (registered && authenticated) {
            System.out.println("SUCCESS: file-fallback register+authenticate worked.");
            System.exit(0);
        } else {
            System.out.println("FAIL: file-fallback did not work as expected.");
            System.exit(2);
        }
    }
}
