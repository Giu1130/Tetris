package tetris.util;

public class RankingEntry implements Comparable<RankingEntry> {
    public String playerName;
    public int score;
    public int level;
    public int lines;
    public String difficulty;
    public long timestamp;

    public RankingEntry(String playerName, int score, int level, int lines, String difficulty) {
        this.playerName = playerName;
        this.score = score;
        this.level = level;
        this.lines = lines;
        this.difficulty = difficulty;
        this.timestamp = System.currentTimeMillis();
    }

    @Override
    public int compareTo(RankingEntry other) {
        if (this.score != other.score) {
            return Integer.compare(other.score, this.score); // descending
        }
        return Long.compare(this.timestamp, other.timestamp); // older first if same score
    }

    @Override
    public String toString() {
        return String.format("%-20s | %6d pts | Nv:%2d | %s", playerName, score, level, difficulty);
    }
}
