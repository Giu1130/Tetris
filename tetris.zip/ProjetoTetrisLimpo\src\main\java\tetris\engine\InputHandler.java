package tetris.engine;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import tetris.domain.Partida;

public class InputHandler extends KeyAdapter {
    private final Partida partida;
    public InputHandler(Partida p){ this.partida = p; }
    @Override
    public void keyPressed(KeyEvent e){
        if(partida.isGameOver()) return;
        switch(e.getKeyCode()){
            case KeyEvent.VK_LEFT -> partida.moveLeft();
            case KeyEvent.VK_RIGHT -> partida.moveRight();
            case KeyEvent.VK_UP -> partida.rotate();
            case KeyEvent.VK_SPACE -> partida.hardDrop();
            case KeyEvent.VK_DOWN -> partida.softDrop();
            case KeyEvent.VK_C -> partida.hold();
            case KeyEvent.VK_P -> { /* pause handled by UI */ }
        }
    }
}
