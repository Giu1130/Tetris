package tetris.ui;

import javax.swing.*;
import java.awt.*;

public class ScorePanel extends JPanel {
    private final JLabel lblP = new JLabel("PONTUAÇÃO: 0");
    private final JLabel lblN = new JLabel("NÍVEL: 1");
    private final JLabel lblL = new JLabel("LINHAS: 0");
    private final JLabel lblT = new JLabel("TEMPO: 00:00");
    private final JLabel lblS = new JLabel("");

    public ScorePanel(){
        setLayout(new GridLayout(5, 1, 0, 4));
        setPreferredSize(new Dimension(160, 150));
        setBackground(TetrisColors.getBgMedium());
        setBorder(BorderFactory.createLineBorder(TetrisColors.getAccent(), 2));

        lblP.setForeground(TetrisColors.getAccent());
        lblN.setForeground(TetrisColors.getTextPrimary());
        lblL.setForeground(TetrisColors.getTextPrimary());
        lblT.setForeground(TetrisColors.getTextPrimary());
        lblS.setForeground(TetrisColors.getAccent());

        lblP.setFont(TetrisColors.getScoreFont());
        lblN.setFont(TetrisColors.getScoreFont());
        lblL.setFont(TetrisColors.getScoreFont());
        lblT.setFont(TetrisColors.getScoreFont());
        lblS.setFont(TetrisColors.getLabelFont());

        add(lblP);
        add(lblN);
        add(lblL);
        add(lblT);
        add(lblS);
    }

    public void atualizar(int pontos, int nivel, int linhas){
        lblP.setText(String.format("PONTUAÇÃO: %06d", pontos));
        lblN.setText("NÍVEL: " + nivel);
        lblL.setText("LINHAS: " + linhas);
    }

    public void atualizarTempo(int segundos){
        int min = segundos/60;
        int sec = segundos%60;
        lblT.setText(String.format("TEMPO: %02d:%02d", min, sec));
    }

    public void setStatus(String s){ 
        lblS.setText(s); 
    }

    public void applyTheme() {
        setBackground(TetrisColors.getBgMedium());
        setBorder(BorderFactory.createLineBorder(TetrisColors.getAccent(), 2));
        lblP.setForeground(TetrisColors.getAccent());
        lblN.setForeground(TetrisColors.getTextPrimary());
        lblL.setForeground(TetrisColors.getTextPrimary());
        lblT.setForeground(TetrisColors.getTextPrimary());
        lblS.setForeground(TetrisColors.getAccent());
        repaint();
    }
}
