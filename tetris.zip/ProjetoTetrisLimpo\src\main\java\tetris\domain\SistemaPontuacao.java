package tetris.domain;

public class SistemaPontuacao {
    private int pontos = 0;
    private int nivel = 1;
    private int linhas = 0;

    public synchronized void adicionarLinhas(int n){
        if(n<=0) return;
        linhas += n;
        int ganho = switch(n){
            case 1 -> 40 * nivel;   // Single
            case 2 -> 100 * nivel;  // Double
            case 3 -> 300 * nivel;  // Triple
            case 4 -> 1200 * nivel; // Tetris
            default -> 0;
        };
        pontos += ganho;
        // clássico: aumenta nível a cada 10 linhas completas
        nivel = (linhas / 10) + 1;
    }
    public synchronized void adicionarSoftDrop(int steps){
        if(steps<=0) return;
        pontos += steps; // 1 ponto por célula
    }
    public synchronized void adicionarHardDrop(int steps){
        if(steps<=0) return;
        pontos += steps * 2; // 2 pontos por célula (mais reward)
    }
    public synchronized int getPontos(){ return pontos; }
    public synchronized int getNivel(){ return nivel; }
    public synchronized int getLinhas(){ return linhas; }
}
