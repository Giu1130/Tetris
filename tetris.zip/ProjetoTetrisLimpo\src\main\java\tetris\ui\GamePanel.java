package tetris.ui;

import javax.swing.*;
import java.awt.*;
import tetris.domain.Tabuleiro;
import tetris.domain.Tetromino;
import tetris.domain.Posicao;

public class GamePanel extends JPanel {
    private Tabuleiro tab;
    private Tetromino atual;
    public static final int CELL = 30;
    private static final int BORDER = 3;
    private boolean pausado = false;

    public GamePanel(Tabuleiro tab, Tetromino atual){
        this.tab = tab; this.atual = atual;
        setPreferredSize(new Dimension(Tabuleiro.LARGURA*CELL, Tabuleiro.ALTURA*CELL));
        setBackground(TetrisColors.getBgDark());
        setBorder(BorderFactory.createLineBorder(TetrisColors.getAccent(), 3));
    }

    public void atualizar(Tabuleiro tab, Tetromino atual){
        this.tab = tab; this.atual = atual; repaint();
    }

    public void setPausado(boolean p) { this.pausado = p; }

    private void drawBlock3D(Graphics2D g2, int x, int y, Color color) {
        // Preenche com cor principal
        g2.setColor(color);
        g2.fillRect(x, y, CELL, CELL);
        
        // Borda superior/esquerda (clara)
        g2.setColor(new Color(
            Math.min(color.getRed() + 80, 255),
            Math.min(color.getGreen() + 80, 255),
            Math.min(color.getBlue() + 80, 255)
        ));
        g2.fillRect(x, y, CELL, BORDER);
        g2.fillRect(x, y, BORDER, CELL);
        
        // Borda inferior/direita (escura)
        g2.setColor(new Color(
            Math.max(color.getRed() - 60, 0),
            Math.max(color.getGreen() - 60, 0),
            Math.max(color.getBlue() - 60, 0)
        ));
        g2.fillRect(x, y + CELL - BORDER, CELL, BORDER);
        g2.fillRect(x + CELL - BORDER, y, BORDER, CELL);
        
        // Contorno
        g2.setColor(Color.BLACK);
        g2.drawRect(x, y, CELL - 1, CELL - 1);
    }

    @Override
    protected void paintComponent(Graphics g){
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        boolean[][] grid = tab.getGrid();
        // draw fixed blocks
        for(int y=0;y<Tabuleiro.ALTURA;y++) for(int x=0;x<Tabuleiro.LARGURA;x++){
            if(grid[y][x]){
                drawBlock3D(g2, x*CELL, y*CELL, new Color(100, 150, 200));
            }
        }
        // draw ghost piece (posição mais baixa válida)
        Tetromino ghost = new Tetromino(atual.getForma(), atual.getCor(), new Posicao(atual.getPos().x(), atual.getPos().y()));
        while(tab.posicaoValida(ghost)) ghost.moverBaixo();
        ghost.moverCima();
        boolean[][] fg = ghost.getForma();
        Posicao gp = ghost.getPos();
        Color base = atual.getCor();
        Color ghostColor = new Color(base.getRed(), base.getGreen(), base.getBlue(), 80);
        g2.setColor(ghostColor);
        for(int r=0;r<fg.length;r++) for(int c=0;c<fg[r].length;c++){
            if(fg[r][c]){
                int x = (gp.x()+c)*CELL;
                int y = (gp.y()+r)*CELL;
                g2.fillRect(x, y, CELL, CELL);
            }
        }

        // draw actual piece com estilo 3D
        boolean[][] f = atual.getForma();
        Posicao p = atual.getPos();
        for(int r=0;r<f.length;r++) for(int c=0;c<f[r].length;c++){
            if(f[r][c]){
                int x = (p.x()+c)*CELL;
                int y = (p.y()+r)*CELL;
                drawBlock3D(g2, x, y, atual.getCor());
            }
        }
    // grid lines (theme-controlled)
    g2.setColor(TetrisColors.getGridLine());
        for(int x=0;x<=Tabuleiro.LARGURA;x++) g2.drawLine(x*CELL,0,x*CELL,Tabuleiro.ALTURA*CELL);
        for(int y=0;y<=Tabuleiro.ALTURA;y++) g2.drawLine(0,y*CELL,Tabuleiro.LARGURA*CELL,y*CELL);

        // draw pause overlay
        if(pausado){
            g2.setColor(new Color(0, 0, 0, 150));
            g2.fillRect(0, 0, getWidth(), getHeight());
            g2.setColor(TetrisColors.ACCENT);
            g2.setFont(TetrisColors.getTitleFont());
            String txt = "PAUSADO";
            FontMetrics fm = g2.getFontMetrics();
            int x = (getWidth() - fm.stringWidth(txt)) / 2;
            int y = (getHeight() + fm.getAscent()) / 2;
            g2.drawString(txt, x, y);
        }
    }
}
