package tetris.ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import tetris.domain.Partida;
import tetris.domain.Jogador;
import tetris.engine.InputHandler;

public class TelaPrincipal extends JFrame {
    private Partida partida;
    private final GamePanel gamePanel;
    private final NextPiecePanel nextPanel;
    private final HoldPanel holdPanel;
    private final ScorePanel scorePanel;
    private final Timer renderTimer;
    private final Timer dropTimer;
    private Timer clockTimer;
    private int segundosDecorridos = 0;
    private boolean pausado = false;
    private KeyAdapter inputHandler;
    private KeyAdapter controlAdapter;
    private double difficultyMultiplier = 1.0;
    private String selectedDifficulty = "Normal";

    public TelaPrincipal(Partida p){
        super("TETRIS - " + p.getJogador().getNome());
        this.partida = p;
        this.gamePanel = new GamePanel(p.getTabuleiro(), p.getAtual());
        this.nextPanel = new NextPiecePanel();
        this.holdPanel = new HoldPanel();
        this.scorePanel = new ScorePanel();

        setLayout(new BorderLayout(12, 12));
        setBackground(TetrisColors.getBgDark());
        getContentPane().setBackground(TetrisColors.getBgDark());

        JPanel leftPanel = new JPanel(new BorderLayout(8, 8));
        leftPanel.setBackground(TetrisColors.getBgDark());
        leftPanel.add(holdPanel, BorderLayout.NORTH);
        leftPanel.add(scorePanel, BorderLayout.CENTER);

        add(gamePanel, BorderLayout.CENTER);
        add(leftPanel, BorderLayout.WEST);

        JPanel rightPanel = new JPanel(new BorderLayout());
        rightPanel.setBackground(TetrisColors.getBgDark());
        rightPanel.add(nextPanel, BorderLayout.CENTER);
        add(rightPanel, BorderLayout.EAST);

        JPanel top = createControlPanel();
        add(top, BorderLayout.NORTH);

        // inputHandler will be added when the user clicks Iniciar
        inputHandler = new InputHandler(partida);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setIconImage(createTetrisIcon());
    // initialize panels with current partida state so UI shows pieces/score before Start
    nextPanel.setQueue(partida.getNextQueue());
    holdPanel.setHeld(partida.getSegurada());
    scorePanel.atualizar(partida.getScore().getPontos(), partida.getScore().getNivel(), partida.getScore().getLinhas());
    pack();
        setResizable(false);
        setLocationRelativeTo(null);

        renderTimer = new Timer(1000/60, e -> atualizarTela());
        int initialDelay = 1000;
        dropTimer = new Timer(initialDelay, e -> {
            if(!pausado) partida.tickDrop();
            atualizarDropInterval();
        });

        clockTimer = new Timer(1000, e -> {
            if(!pausado) {
                segundosDecorridos++;
                scorePanel.atualizarTempo(segundosDecorridos);
            }
        });
    }

    private JPanel createControlPanel(){
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 6));
        top.setBackground(TetrisColors.getBgMedium());
        top.setBorder(BorderFactory.createLineBorder(TetrisColors.getAccent(), 1));

        JButton btnPause = new JButton("P - Pausar");
        btnPause.setFont(new Font("Arial", Font.BOLD, 12));
        btnPause.setBackground(TetrisColors.getAccent());
        btnPause.setForeground(Color.WHITE);
        btnPause.setFocusPainted(false);

        JButton btnRestart = new JButton("R - Reiniciar");
        btnRestart.setFont(new Font("Arial", Font.BOLD, 12));
        btnRestart.setBackground(TetrisColors.getAccent());
        btnRestart.setForeground(Color.WHITE);
        btnRestart.setFocusPainted(false);

        JButton btnStop = new JButton("Parar & Registrar");
        btnStop.setFont(new Font("Arial", Font.BOLD, 12));
        btnStop.setBackground(new Color(0xFF6600));
        btnStop.setForeground(Color.WHITE);
        btnStop.setFocusPainted(false);

    String[] diffs = {"Fácil", "Normal", "Difícil", "Hardcore"};
        JComboBox<String> cbDifficulty = new JComboBox<>(diffs);
        cbDifficulty.setSelectedIndex(1);
        cbDifficulty.setFont(new Font("Arial", Font.PLAIN, 11));

        String[] themes = new String[TetrisTheme.getAllThemes().length];
        for (int i = 0; i < themes.length; i++) {
            themes[i] = TetrisTheme.getAllThemes()[i].displayName;
        }
        JComboBox<String> cbTheme = new JComboBox<>(themes);
        cbTheme.setSelectedIndex(0);
        cbTheme.setFont(new Font("Arial", Font.PLAIN, 11));

        JLabel lblDiff = new JLabel("Dificuldade:");
        lblDiff.setFont(new Font("Arial", Font.BOLD, 12));
        lblDiff.setForeground(TetrisColors.getTextPrimary());

        JLabel lblTheme = new JLabel("Tema:");
        lblTheme.setFont(new Font("Arial", Font.BOLD, 12));
        lblTheme.setForeground(TetrisColors.getTextPrimary());

        JButton btnRanking = new JButton("Ranking");
        btnRanking.setFont(new Font("Arial", Font.BOLD, 12));
        btnRanking.setBackground(new Color(0x4455aa));
        btnRanking.setForeground(Color.WHITE);
        btnRanking.setFocusPainted(false);

        top.add(lblDiff);
        top.add(cbDifficulty);
        top.add(lblTheme);
        top.add(cbTheme);
    top.add(new JSeparator(JSeparator.VERTICAL));
    top.add(btnPause);
    top.add(btnRestart);
    top.add(btnStop);
    // Start button (user clicks after login to begin playing)
    JButton btnStart = new JButton("Iniciar");
    btnStart.setFont(new Font("Arial", Font.BOLD, 12));
    btnStart.setBackground(new Color(0x2288cc));
    btnStart.setForeground(Color.WHITE);
    btnStart.setFocusPainted(false);
    btnStart.addActionListener(e -> startGame());
    top.add(btnStart);
    top.add(btnRanking);

    JButton btnStats = new JButton("📊 Estatísticas");
    btnStats.setFont(new Font("Arial", Font.BOLD, 12));
    btnStats.setBackground(new Color(0x44aa55));
    btnStats.setForeground(Color.WHITE);
    btnStats.setFocusPainted(false);
    btnStats.addActionListener(e -> showStatistics());
    top.add(btnStats);

        btnPause.addActionListener(e -> togglePause());
        btnRestart.addActionListener(e -> restartGame());
        btnStop.addActionListener(e -> stopAndRegister());
        cbDifficulty.addActionListener(e -> {
            String s = (String)cbDifficulty.getSelectedItem();
            selectedDifficulty = s;
            switch(s){
                case "Fácil" -> difficultyMultiplier = 1.4;
                case "Normal" -> difficultyMultiplier = 1.0;
                case "Difícil" -> difficultyMultiplier = 0.7;
                case "Hardcore" -> difficultyMultiplier = 0.5;
                default -> difficultyMultiplier = 1.0;
            }
            atualizarDropInterval();
        });

        cbTheme.addActionListener(e -> {
            TetrisTheme.ThemeName themeName = TetrisTheme.getAllThemes()[cbTheme.getSelectedIndex()];
            TetrisTheme.setTheme(themeName);
            // Apply theme only to the game area and related UI elements (background, board and grid lines)
            applyTheme();
        });

        btnRanking.addActionListener(e -> showRanking());

        return top;
    }

    private Image createTetrisIcon(){
        // Tentar carregar ícone da imagem
        javax.swing.ImageIcon loadedIcon = tetris.util.ImageLoader.getAppIcon();
        if (loadedIcon != null && loadedIcon.getImage() != null) {
            return loadedIcon.getImage();
        }
        
        // Fallback: criar ícone simples
        BufferedImage img = new BufferedImage(16, 16, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = img.createGraphics();
        g.setColor(TetrisColors.BG_DARK);
        g.fillRect(0, 0, 16, 16);
        g.setColor(TetrisColors.CYAN);
        g.fillRect(4, 4, 8, 8);
        g.dispose();
        return img;
    }

    public void iniciar(){
        // Show UI but do not start game timers yet; user must click Iniciar
        setVisible(true);
        this.requestFocusInWindow();
        this.requestFocus();
    }

    private boolean started = false;

    public void startGame() {
        if (started) return;
        started = true;
        // (re)create input handler bound to current partida
        inputHandler = new tetris.engine.InputHandler(partida);
        addKeyListener(inputHandler);
        // control adapter for pause/restart
        controlAdapter = new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_P) togglePause();
                if (e.getKeyCode() == KeyEvent.VK_R) restartGame();
            }
        };
        addKeyListener(controlAdapter);

        renderTimer.start();
        dropTimer.start();
        clockTimer.start();
        this.requestFocusInWindow();
    }

    private void togglePause(){
        pausado = !pausado;
        gamePanel.setPausado(pausado);
        if(pausado){
            scorePanel.setStatus(">>> PAUSADO <<<");
        } else {
            scorePanel.setStatus("");
        }
    }

    private void restartGame(){
        renderTimer.stop();
        dropTimer.stop();
        clockTimer.stop();
        segundosDecorridos = 0;
        scorePanel.atualizarTempo(0);
        scorePanel.setStatus("");

        Jogador j = partida.getJogador();
        this.partida = new Partida(j);

        removeKeyListener(inputHandler);
        inputHandler = new InputHandler(partida);
        addKeyListener(inputHandler);

        gamePanel.atualizar(partida.getTabuleiro(), partida.getAtual());
        gamePanel.setPausado(false);
        nextPanel.setQueue(partida.getNextQueue());
        holdPanel.setHeld(partida.getSegurada());
        scorePanel.atualizar(partida.getScore().getPontos(), partida.getScore().getNivel(), partida.getScore().getLinhas());

        pausado = false;
        atualizarDropInterval();
        renderTimer.start();
        dropTimer.start();
        clockTimer.start();
        this.requestFocusInWindow();
        this.requestFocus();
    }

    private void atualizarDropInterval(){
        int nivel = partida.getScore().getNivel();
        int base = switch(nivel){
            case 1,2,3 -> 1000;
            case 4,5,6 -> 700;
            default -> 400;
        };
        int delay = (int)(base * difficultyMultiplier);
        if(dropTimer.getDelay() != delay) dropTimer.setDelay(delay);
    }

    private void atualizarTela(){
        gamePanel.atualizar(partida.getTabuleiro(), partida.getAtual());
        nextPanel.setQueue(partida.getNextQueue());
        holdPanel.setHeld(partida.getSegurada());
        scorePanel.atualizar(partida.getScore().getPontos(), partida.getScore().getNivel(), partida.getScore().getLinhas());
        if(partida.isGameOver()){
            renderTimer.stop();
            dropTimer.stop();
            clockTimer.stop();
            
            // use selectedDifficulty chosen by the player
            String difficulty = selectedDifficulty;

            GameOverDialog dialog = new GameOverDialog(
                this,
                partida.getScore().getPontos(),
                partida.getScore().getNivel(),
                partida.getScore().getLinhas(),
                partida.getJogador().getNome(),
                difficulty,
                true
            );
            dialog.setVisible(true);
            dispose();
        }
    }

    private void stopAndRegister(){
        renderTimer.stop();
        dropTimer.stop();
        clockTimer.stop();
        
        // use selectedDifficulty chosen by the player
        String difficulty = selectedDifficulty;

        GameOverDialog dialog = new GameOverDialog(
            this,
            partida.getScore().getPontos(),
            partida.getScore().getNivel(),
            partida.getScore().getLinhas(),
            partida.getJogador().getNome(),
            difficulty,
            false
        );
        dialog.setVisible(true);
        dispose();
    }

    private void applyTheme() {
        // frame and content
        getContentPane().setBackground(TetrisColors.getBgDark());
        this.getRootPane().setBackground(TetrisColors.getBgDark());

        // panels
        gamePanel.setBackground(TetrisColors.getBgDark());
        gamePanel.setBorder(BorderFactory.createLineBorder(TetrisColors.getAccent(), 3));
        nextPanel.applyTheme();
        holdPanel.applyTheme();
        scorePanel.applyTheme();

        // repaint to show grid line color changes
        gamePanel.repaint();
        nextPanel.repaint();
        holdPanel.repaint();
        scorePanel.repaint();
    }

    private void showStatistics() {
        StatisticsPanel statsFrame = new StatisticsPanel();
        statsFrame.setVisible(true);
    }

    private void showRanking(){
        JFrame rankingFrame = new JFrame("Ranking - TETRIS");
        rankingFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        rankingFrame.add(new RankingPanel(rankingFrame));
        rankingFrame.pack();
        rankingFrame.setLocationRelativeTo(this);
        rankingFrame.setVisible(true);
    }
}
