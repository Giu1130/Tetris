package tetris.domain;
public record Posicao(int x, int y) { }
