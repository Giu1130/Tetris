ProjetoTetrisLimpo - instruções
Rodar com Maven:
mvn clean compile
mvn exec:java

Controles:
← → : mover
↑ : rotacionar
↓ : queda lenta (segurar para acelerar)
Space : queda rápida (hard drop)
P : (não implementado na UI) pausa (pode implementar com botão)
