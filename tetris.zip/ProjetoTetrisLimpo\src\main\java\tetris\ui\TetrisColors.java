package tetris.ui;

import java.awt.Color;
import java.awt.Font;

public class TetrisColors {
    // Tetromino colors (dynamic via theme)
    public static Color getCyan() { return TetrisTheme.getCurrent().cyan; }
    public static Color getYellow() { return TetrisTheme.getCurrent().yellow; }
    public static Color getPurple() { return TetrisTheme.getCurrent().purple; }
    public static Color getGreen() { return TetrisTheme.getCurrent().green; }
    public static Color getRed() { return TetrisTheme.getCurrent().red; }
    public static Color getBlue() { return TetrisTheme.getCurrent().blue; }
    public static Color getOrange() { return TetrisTheme.getCurrent().orange; }

    // Static reference for backward compatibility
    public static final Color CYAN = new Color(0x00FFFF);
    public static final Color YELLOW = new Color(0xFFFF00);
    public static final Color PURPLE = new Color(0x800080);
    public static final Color GREEN = new Color(0x00FF00);
    public static final Color RED = new Color(0xFF0000);
    public static final Color BLUE = new Color(0x0000FF);
    public static final Color ORANGE = new Color(0xFFA500);

    // UI Colors (dynamic via theme)
    public static Color getBgDark() { return TetrisTheme.getCurrent().bgDark; }
    public static Color getBgMedium() { return TetrisTheme.getCurrent().bgMedium; }
    public static Color getAccent() { return TetrisTheme.getCurrent().accent; }
    public static Color getTextPrimary() { return TetrisTheme.getCurrent().textPrimary; }
    public static Color getTextSecondary() { return TetrisTheme.getCurrent().textSecondary; }

    // Grid line color (dynamic via theme)
    public static Color getGridLine() { return TetrisTheme.getCurrent().gridLine; }

    // Static defaults for backward compatibility
    public static final Color BG_DARK = new Color(0x1a1a2e);
    public static final Color BG_MEDIUM = new Color(0x16213e);
    public static final Color BORDER_LIGHT = new Color(0x0f3460);
    public static final Color ACCENT = new Color(0xe94560);
    public static final Color TEXT_PRIMARY = Color.WHITE;
    public static final Color TEXT_SECONDARY = new Color(0xcccccc);

    // Game field colors
    public static final Color GRID_LINE = new Color(0x333333);
    public static final Color BLOCK_BORDER = Color.BLACK;
    public static final Color GHOST_ALPHA = new Color(0, 0, 0, 100);

    // Game-style fonts
    public static Font getTitleFont() {
        return new Font("Arial", Font.BOLD, 28);
    }

    public static Font getScoreFont() {
        return new Font("Courier New", Font.BOLD, 15);
    }

    public static Font getLabelFont() {
        return new Font("Arial", Font.BOLD, 13);
    }

    public static Font getSmallFont() {
        return new Font("Arial", Font.PLAIN, 11);
    }

    public static Font getGameFont() {
        return new Font("Courier New", Font.BOLD, 20);
    }
}
