package tetris.util;

import java.sql.*;

public class DatabaseManager {
    // SQL Server configuration
    private static final String SERVER = "localhost";
    private static final int PORT = 1433;
    private static final String DATABASE = "TetrisGame";
    private static final String USERNAME = "sa";
    private static final String PASSWORD = "YourPassword123!";
    
    private static final String DB_URL = "jdbc:sqlserver://" + SERVER + ":" + PORT 
            + ";databaseName=" + DATABASE 
            + ";encrypt=false;trustServerCertificate=true";
    
    private static Connection connection;

    public static void init() {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            connection = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            createTables();
            System.out.println("✓ SQL Server database connected successfully!");
        } catch (ClassNotFoundException e) {
            System.err.println("✗ SQL Server driver not found: " + e.getMessage());
        } catch (SQLException e) {
            System.err.println("✗ Não foi possível conectar ao SQL Server: " + e.getMessage());
            System.err.println("  Certifique-se de que SQL Server está rodando em " + SERVER + ":" + PORT);
            System.err.println("  Usando fallback para arquivo de usuários (users.txt)");
        }
    }

    private static void createTables() throws SQLException {
        String usersTable = "IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'usuarios') " +
                "CREATE TABLE usuarios (" +
                "id INT PRIMARY KEY IDENTITY(1,1)," +
                "username NVARCHAR(100) UNIQUE NOT NULL," +
                "password NVARCHAR(256) NOT NULL," +
                "data_criacao DATETIME DEFAULT GETDATE())";

        String rankingTable = "IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'ranking') " +
                "CREATE TABLE ranking (" +
                "id INT PRIMARY KEY IDENTITY(1,1)," +
                "usuario_id INT NOT NULL," +
                "pontuacao INT NOT NULL," +
                "nivel INT NOT NULL," +
                "linhas INT NOT NULL," +
                "dificuldade NVARCHAR(50) NOT NULL," +
                "data_partida DATETIME DEFAULT GETDATE()," +
                "FOREIGN KEY (usuario_id) REFERENCES usuarios(id))";

        try (Statement stmt = connection.createStatement()) {
            stmt.execute(usersTable);
            stmt.execute(rankingTable);
            System.out.println("✓ Tabelas verificadas/criadas com sucesso");
        }
    }

    public static Connection getConnection() {
        return connection;
    }

    public static void closeConnection() {
        try {
            if (connection != null) {
                connection.close();
            }
        } catch (SQLException e) {
            System.err.println("Erro ao fechar conexão: " + e.getMessage());
        }
    }

    public static boolean addUser(String username, String hashedPassword) {
        String sql = "INSERT INTO usuarios (username, password) VALUES (?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, username);
            pstmt.setString(2, hashedPassword);
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.err.println("Erro ao adicionar usuário: " + e.getMessage());
            return false;
        }
    }

    public static String getUserPassword(String username) {
        String sql = "SELECT password FROM usuarios WHERE username = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, username);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getString("password");
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar usuário: " + e.getMessage());
        }
        return null;
    }

    public static int getUserId(String username) {
        String sql = "SELECT id FROM usuarios WHERE username = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, username);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("id");
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar ID do usuário: " + e.getMessage());
        }
        return -1;
    }

    public static void addRanking(int usuarioId, int pontuacao, int nivel, int linhas, String dificuldade) {
        String sql = "INSERT INTO ranking (usuario_id, pontuacao, nivel, linhas, dificuldade) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, usuarioId);
            pstmt.setInt(2, pontuacao);
            pstmt.setInt(3, nivel);
            pstmt.setInt(4, linhas);
            pstmt.setString(5, dificuldade);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Erro ao adicionar ranking: " + e.getMessage());
        }
    }

    public static ResultSet getTop10(String dificuldade) {
        String sql = "SELECT u.username, r.pontuacao, r.nivel, r.linhas, r.dificuldade, r.data_partida " +
                "FROM ranking r JOIN usuarios u ON r.usuario_id = u.id " +
                "WHERE r.dificuldade = ? " +
                "ORDER BY r.pontuacao DESC LIMIT 10";
        try {
            PreparedStatement pstmt = connection.prepareStatement(sql);
            pstmt.setString(1, dificuldade);
            return pstmt.executeQuery();
        } catch (SQLException e) {
            System.err.println("Erro ao buscar top 10: " + e.getMessage());
        }
        return null;
    }
}
