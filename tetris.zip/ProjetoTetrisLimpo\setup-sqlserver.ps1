# ============================================
# Script para instalar e configurar SQL Server
# Executar como ADMINISTRADOR
# ============================================

Write-Host "╔════════════════════════════════════════╗"
Write-Host "║  SETUP SQL SERVER PARA TETRIS GAME    ║"
Write-Host "╚════════════════════════════════════════╝" -ForegroundColor Cyan

# Verificar se está rodando como admin
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")
if (-not $isAdmin) {
    Write-Host "❌ Este script deve ser executado como ADMINISTRADOR!" -ForegroundColor Red
    Read-Host "Pressione ENTER para sair"
    exit
}

Write-Host "`n📋 Opções de instalação:" -ForegroundColor Yellow
Write-Host "1. Usar Docker (Recomendado - mais fácil)"
Write-Host "2. Instalar SQL Server Express local"
Write-Host "3. Apenas verificar conexão (já tenho SQL Server)"
$option = Read-Host "`nEscolha uma opção (1-3)"

# ==========================================
# OPÇÃO 1: Docker
# ==========================================
if ($option -eq "1") {
    Write-Host "`n🐳 Verificando Docker..." -ForegroundColor Cyan
    
    $docker = Get-Command docker -ErrorAction SilentlyContinue
    if (-not $docker) {
        Write-Host "❌ Docker não encontrado!" -ForegroundColor Red
        Write-Host "📥 Baixe em: https://www.docker.com/products/docker-desktop"
        Read-Host "Pressione ENTER para sair"
        exit
    }
    
    Write-Host "✓ Docker encontrado!" -ForegroundColor Green
    Write-Host "`n📦 Iniciando container SQL Server..." -ForegroundColor Cyan
    
    docker run -e "ACCEPT_EULA=Y" -e "SA_PASSWORD=YourPassword123!" `
      -p 1433:1433 `
      --name sqlserver-tetris `
      -d mcr.microsoft.com/mssql/server:latest
    
    Start-Sleep -Seconds 5
    
    Write-Host "✓ Container iniciado!" -ForegroundColor Green
    Write-Host "⏳ Aguardando SQL Server iniciar (pode levar 30 segundos)..." -ForegroundColor Yellow
    Start-Sleep -Seconds 30
    
    Write-Host "`n✓ SQL Server deve estar rodando em localhost:1433" -ForegroundColor Green
}

# ==========================================
# OPÇÃO 2: SQL Server Express
# ==========================================
elseif ($option -eq "2") {
    Write-Host "`n📥 Baixando SQL Server Express..." -ForegroundColor Cyan
    
    $installerUrl = "https://go.microsoft.com/fwlink/p/?linkid=2216019"
    $installerPath = "$env:TEMP\SQLServer2022-SSEI-Express.exe"
    
    Write-Host "Salvando em: $installerPath"
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    Invoke-WebRequest -Uri $installerUrl -OutFile $installerPath
    
    Write-Host "`n✓ Download concluído!" -ForegroundColor Green
    Write-Host "🔧 Abrindo instalador..." -ForegroundColor Cyan
    
    & $installerPath
    
    Write-Host "`n⚠️  Siga os passos no instalador:" -ForegroundColor Yellow
    Write-Host "1. Selecione 'Download Media'"
    Write-Host "2. Selecione 'Express' Edition"
    Write-Host "3. Durante a instalação:"
    Write-Host "   - Escolha 'SQL Server and Windows Authentication'"
    Write-Host "   - Senha para 'sa': YourPassword123!"
    Write-Host "   - Adicione seu usuário Windows como admin"
    Write-Host "4. Termine a instalação"
}

# ==========================================
# OPÇÃO 3: Verificar conexão
# ==========================================
elseif ($option -eq "3") {
    Write-Host "`n🔍 Verificando conexão..." -ForegroundColor Cyan
}

# ==========================================
# Criar banco de dados
# ==========================================
Write-Host "`n💾 Criando banco de dados TetrisGame..." -ForegroundColor Cyan

$sqlScript = @"
USE master;
GO

-- Dropar banco anterior se existir (opcional)
-- DROP DATABASE IF EXISTS TetrisGame;
-- GO

-- Criar banco de dados
IF NOT EXISTS (SELECT 1 FROM sys.databases WHERE name = 'TetrisGame')
BEGIN
    CREATE DATABASE TetrisGame;
    PRINT 'Banco TetrisGame criado com sucesso!';
END
ELSE
BEGIN
    PRINT 'Banco TetrisGame já existe.';
END
GO

USE TetrisGame;
GO

-- Criar tabela usuarios
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'usuarios')
BEGIN
    CREATE TABLE usuarios (
        id INT PRIMARY KEY IDENTITY(1,1),
        username NVARCHAR(100) UNIQUE NOT NULL,
        password NVARCHAR(256) NOT NULL,
        data_criacao DATETIME DEFAULT GETDATE()
    );
    PRINT 'Tabela usuarios criada!';
END
GO

-- Criar tabela ranking
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'ranking')
BEGIN
    CREATE TABLE ranking (
        id INT PRIMARY KEY IDENTITY(1,1),
        usuario_id INT NOT NULL,
        pontuacao INT NOT NULL,
        nivel INT NOT NULL,
        linhas INT NOT NULL,
        dificuldade NVARCHAR(50) NOT NULL,
        data_partida DATETIME DEFAULT GETDATE(),
        FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
    );
    PRINT 'Tabela ranking criada!';
END
GO

PRINT 'Banco TetrisGame pronto!';
"@

try {
    $sqlScript | sqlcmd -S localhost -U sa -P "YourPassword123!" -d master 2>&1
    Write-Host "✓ Banco de dados configurado com sucesso!" -ForegroundColor Green
}
catch {
    Write-Host "❌ Erro ao criar banco:" -ForegroundColor Red
    Write-Host $_.Exception.Message
    Write-Host "`n⚠️  Certifique-se de que SQL Server está rodando!" -ForegroundColor Yellow
}

# ==========================================
# Resumo Final
# ==========================================
Write-Host "`n╔════════════════════════════════════════╗"
Write-Host "║  ✓ CONFIGURAÇÃO CONCLUÍDA!            ║"
Write-Host "╚════════════════════════════════════════╝" -ForegroundColor Green

Write-Host "`n📊 Informações de conexão:" -ForegroundColor Yellow
Write-Host "  Servidor: localhost"
Write-Host "  Porta: 1433"
Write-Host "  Banco: TetrisGame"
Write-Host "  Usuário: sa"
Write-Host "  Senha: YourPassword123!"

Write-Host "`n🎮 Próximos passos:" -ForegroundColor Cyan
Write-Host "1. Abra o projeto Tetris"
Write-Host "2. Execute: mvn -DskipTests compile"
Write-Host "3. Execute: mvn -DskipTests exec:java"
Write-Host "4. Faça login e jogue!"

Write-Host "`n📖 Para mais informações:" -ForegroundColor Cyan
Write-Host "  Veja: GUIA_SQL_SERVER.md"

Read-Host "`nPressione ENTER para finalizar"
