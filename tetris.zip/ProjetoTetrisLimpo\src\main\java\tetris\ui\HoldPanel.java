package tetris.ui;

import javax.swing.*;
import java.awt.*;
import tetris.domain.Tetromino;

public class HoldPanel extends JPanel {
    private Tetromino held;

    public HoldPanel() {
        setPreferredSize(new Dimension(120, 100));
        setBackground(TetrisColors.getBgMedium());
        setBorder(BorderFactory.createLineBorder(TetrisColors.getAccent(), 2));
    }

    public void applyTheme() {
        setBackground(TetrisColors.getBgMedium());
        setBorder(BorderFactory.createLineBorder(TetrisColors.getAccent(), 2));
        repaint();
    }

    public void setHeld(Tetromino t) {
        this.held = t;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Title
        g2.setColor(TetrisColors.ACCENT);
        g2.setFont(TetrisColors.getLabelFont());
        g2.drawString("HOLD", 40, 18);

        if (held == null) {
            g2.setColor(TetrisColors.getTextSecondary());
            g2.setFont(TetrisColors.getSmallFont());
            g2.drawString("(vazio)", 35, 60);
            return;
        }

        // Draw held piece
        boolean[][] f = held.getForma();
        int cellSize = 20;
        int startX = (getWidth() - f[0].length * cellSize) / 2;
        int startY = 35;

        g2.setColor(held.getCor());
        for (int r = 0; r < f.length; r++) {
            for (int c = 0; c < f[r].length; c++) {
                if (f[r][c]) {
                    int x = startX + c * cellSize;
                    int y = startY + r * cellSize;
                    g2.fillRect(x, y, cellSize - 1, cellSize - 1);
                    g2.setColor(TetrisColors.BLOCK_BORDER);
                    g2.drawRect(x, y, cellSize - 1, cellSize - 1);
                    g2.setColor(held.getCor());
                }
            }
        }
    }
}
