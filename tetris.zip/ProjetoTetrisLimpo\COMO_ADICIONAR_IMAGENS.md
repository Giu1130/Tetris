# 📸 COMO ADICIONAR AS IMAGENS PNG

## ✅ Status Atual

O jogo **funciona 100% sem as imagens** - tudo tem fallback automático:
- ❌ Sem `tetris_logo.png` → Mostra "TETRIS" em texto vermelho
- ❌ Sem `tetris_icon.png` → Usa ícone azul ciano simples

## 🎯 Opcional: Adicionar Imagens PNG

Se quiser usar as imagens PNG coloridas que você enviou:

### Passo 1: Preparar as Imagens

**Para `tetris_logo.png`** (aquela imagem colorida com "TETRIS"):
1. Redimensionar para: **250 x 150 pixels**
2. Formato: PNG (com fundo transparente é melhor)
3. Salvar como: `tetris_logo.png`

**Para `tetris_icon.png`** (ícone do app):
1. Redimensionar para: **32x32 ou 64x64 pixels**
2. Formato: PNG (com fundo transparente é melhor)
3. Salvar como: `tetris_icon.png`

### Passo 2: Colocar no Projeto

```
ProjetoTetrisLimpo/
├── src/
│   └── main/
│       └── resources/           ← Criar este diretório se não existir
│           ├── tetris_logo.png  ← Aqui
│           └── tetris_icon.png  ← Aqui
└── pom.xml
```

**Criar manualmente:**
```powershell
# No PowerShell, dentro da pasta do projeto:
mkdir -Force src\main\resources

# Copiar as imagens para lá:
Copy-Item "C:\caminho\para\tetris_logo.png" "src\main\resources\"
Copy-Item "C:\caminho\para\tetris_icon.png" "src\main\resources\"
```

### Passo 3: Recompilar

```powershell
cd "C:\Users\Giulia Barros\Downloads\ProjetoTetrisLimpo"

# Compilar
mvn clean compile -DskipTests

# Empacotar
mvn package -DskipTests

# Executar
java -jar target/ProjetoTetrisLimpo-1.0-SNAPSHOT.jar
```

### Passo 4: Verificar

Quando abrir o app:
1. **Login**: Deve mostrar a imagem colorida do Tetris (250x150)
2. **Window**: Ícone colorido na barra de tarefas (32x32)

---

## 🎨 Recomendações para as Imagens

### tetris_logo.png
- **Dimensões**: 250 x 150 pixels (importante!)
- **Cores**: Colorido (como aquele que você mandou)
- **Fundo**: Transparente (PNG com alpha channel)
- **Formato**: PNG (não JPG)
- **Conteúdo**: Qualquer logo/imagem do Tetris

**Exemplo:**
```
Aquela imagem que você mandou (colorida com TETRIS)
↓
Redimensionar para 250x150
↓
Salvar como tetris_logo.png
↓
Colocar em src/main/resources/
```

### tetris_icon.png
- **Dimensões**: 32x32 ou 64x64 pixels
- **Cores**: Qualquer cor que combine com Tetris
- **Fundo**: Transparente (PNG com alpha channel)
- **Formato**: PNG (não JPG)
- **Conteúdo**: Pode ser:
  - Um bloco de Tetris (quadrado colorido)
  - A letra "T" de Tetris
  - Um ícone abstrato de game
  - Miniatura do logo

**Exemplo simples se não tiver imagem:**
- Abra Paint
- Crie 64x64 pixels
- Desenhe um quadrado colorido (azul, vermelho, amarelo, etc)
- Salva como tetris_icon.png

---

## 📂 Estrutura Final (Com Imagens)

```
ProjetoTetrisLimpo/
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── tetris/
│   │   │       ├── Main.java
│   │   │       ├── domain/
│   │   │       ├── engine/
│   │   │       ├── ui/
│   │   │       └── util/
│   │   │           ├── GifLoader.java
│   │   │           ├── ImageLoader.java      ← NOVO
│   │   │           ├── Ranking.java
│   │   │           └── RankingEntry.java
│   │   └── resources/                        ← NOVO DIRETÓRIO
│   │       ├── tetris_logo.png              ← NOVA IMAGEM
│   │       └── tetris_icon.png              ← NOVA IMAGEM
│   └── test/
├── target/
│   └── ProjetoTetrisLimpo-1.0-SNAPSHOT.jar
├── pom.xml
└── README.txt
```

---

## 🔄 O que Muda com as Imagens

### LOGIN (PlayerNameDialog)

**Sem imagens:**
```
┌──────────────────────────┐
│     TETRIS               │  ← Texto vermelho em Arial Bold 48
│ Digite seu nome...       │
│ [_____________________]  │
│  [ Começar ] [ Sair ]   │
└──────────────────────────┘
```

**Com imagens:**
```
┌──────────────────────────┐
│  [Imagem 250x150px]      │  ← PNG colorido do Tetris
│ Digite seu nome...       │
│ [_____________________]  │
│  [ Começar ] [ Sair ]   │
└──────────────────────────┘
```

### WINDOW ICON

**Sem imagem:**
```
┌─────────────────────────────────┬─ ◯ ▢ ✕
│ [Azul] TETRIS - Giulia          │
```
Ícone é um quadrado azul simples 16x16

**Com imagem:**
```
┌─────────────────────────────────┬─ ◯ ▢ ✕
│ [🎮] TETRIS - Giulia             │
```
Ícone é a imagem colorida 32x32

---

## ✅ Resumo

| Item | Obrigatório? | Se Não Tiver | Se Tiver |
|------|--------------|-------------|----------|
| `tetris_logo.png` | ❌ Não | Mostra "TETRIS" em texto | Mostra imagem 250x150 |
| `tetris_icon.png` | ❌ Não | Ícone azul simples | Ícone customizado |

**Recomendação**: Se tiver as imagens, é só copiar para `src/main/resources/` e recompilar!

---

## 🚀 Comandos Rápidos

```powershell
# 1. Criar diretório de recursos
mkdir -Force src\main\resources

# 2. Copiar imagens (substitua com seus caminhos)
Copy-Item "C:\Users\Giulia\Downloads\tetris_logo.png" "src\main\resources\"
Copy-Item "C:\Users\Giulia\Downloads\tetris_icon.png" "src\main\resources\"

# 3. Recompilar
mvn clean package -DskipTests

# 4. Executar
java -jar target/ProjetoTetrisLimpo-1.0-SNAPSHOT.jar
```

---

**Pronto! 🎨**