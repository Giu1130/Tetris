# 🗄️ CONFIGURAÇÃO DO SQL SERVER - TETRIS

## ✅ O que foi mudado

O banco de dados foi atualizado de **SQLite (arquivo local)** para **SQL Server (servidor real)**.

### Mudanças técnicas:
- **Antes:** `tetris_game.db` (arquivo SQLite)
- **Agora:** SQL Server remoto em `localhost:1433`
- **Banco de dados:** `TetrisGame`
- **Autenticação:** User `sa` com senha configurável

---

## 🚀 COMO CONFIGURAR SQL SERVER

### **OPÇÃO 1: Usar SQL Server Local (Windows)**

#### 1️⃣ **Instalar SQL Server Express** (Grátis)

1. Baixar em: https://www.microsoft.com/en-us/sql-server/sql-server-downloads
2. Selecionar **SQL Server Express** (edição gratuita)
3. Executar o instalador
4. Durante instalação:
   - Instance name: `SQLEXPRESS`
   - Authentication mode: **SQL Server and Windows Authentication mode**
   - Sa password: **YourPassword123!** (ou a senha que preferir)
   - Mixed authentication ✓

#### 2️⃣ **Instalar SQL Server Management Studio (SSMS)** (Grátis)

1. Baixar em: https://learn.microsoft.com/en-us/sql/ssms/download-sql-server-management-studio-ssms
2. Executar instalador
3. Conectar em: `localhost\SQLEXPRESS` com usuário `sa`

#### 3️⃣ **Configurar banco de dados**

No SSMS, executar este script SQL:

```sql
-- Criar banco de dados
CREATE DATABASE TetrisGame;
GO

-- Usar o banco
USE TetrisGame;
GO

-- Criar tabelas
CREATE TABLE usuarios (
    id INT PRIMARY KEY IDENTITY(1,1),
    username NVARCHAR(100) UNIQUE NOT NULL,
    password NVARCHAR(256) NOT NULL,
    data_criacao DATETIME DEFAULT GETDATE()
);

CREATE TABLE ranking (
    id INT PRIMARY KEY IDENTITY(1,1),
    usuario_id INT NOT NULL,
    pontuacao INT NOT NULL,
    nivel INT NOT NULL,
    linhas INT NOT NULL,
    dificuldade NVARCHAR(50) NOT NULL,
    data_partida DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);
```

---

### **OPÇÃO 2: Usar Docker (Mais fácil, sem instalação)**

Se você tiver Docker instalado, rode este comando:

```powershell
docker run -e "ACCEPT_EULA=Y" -e "SA_PASSWORD=YourPassword123!" `
  -p 1433:1433 `
  --name sqlserver `
  -d mcr.microsoft.com/mssql/server:latest
```

Depois conecte em `localhost:1433` com usuário `sa`.

---

### **OPÇÃO 3: Usar Azure SQL Database (Cloud)**

Se não tiver SQL Server local:

1. Criar conta em: https://azure.microsoft.com
2. Criar SQL Database
3. Copiar connection string
4. Atualizar em `DatabaseManager.java` (ver abaixo)

---

## ⚙️ CONFIGURAR CONEXÃO NO CÓDIGO

Arquivo: **`src/main/java/tetris/util/DatabaseManager.java`** (linhas 4-9)

```java
private static final String SERVER = "localhost";      // IP do servidor
private static final int PORT = 1433;                  // Porta padrão SQL Server
private static final String DATABASE = "TetrisGame";   // Nome do banco
private static final String USERNAME = "sa";           // Usuário
private static final String PASSWORD = "YourPassword123!";  // Senha
```

**Para mudar a configuração:**

```java
// Exemplo: Conectar em servidor remoto
private static final String SERVER = "seu-servidor.database.windows.net";
private static final String PASSWORD = "SuaSenha@Forte";

// Exemplo: Usar SQL Server autenticado por Windows (sem senha)
// (descomente isto e remova USERNAME/PASSWORD se usar Windows Auth)
```

---

## 🔧 TESTAR CONEXÃO

Após configurar, execute:

```powershell
mvn -DskipTests compile
mvn -DskipTests exec:java
```

### ✅ Se conectou com sucesso:
Você verá:
```
✓ SQL Server database connected successfully!
✓ Tabelas verificadas/criadas com sucesso
```

### ❌ Se der erro:
```
✗ Não foi possível conectar ao SQL Server: ...
  Certifique-se de que SQL Server está rodando em localhost:1433
  Usando fallback para arquivo de usuários (users.txt)
```

**Solução:** O `AuthManager` automaticamente usa `users.txt` como fallback se SQL Server não estiver disponível. Você consegue testar mesmo sem SQL Server!

---

## 📊 VERIFICAR DADOS NO BANCO

### **Usando SQL Server Management Studio (SSMS)**

```sql
USE TetrisGame;

-- Ver usuários
SELECT * FROM usuarios;

-- Ver rankings
SELECT u.username, r.pontuacao, r.dificuldade, r.data_partida
FROM ranking r
JOIN usuarios u ON r.usuario_id = u.id
ORDER BY r.dificuldade, r.pontuacao DESC;

-- Ver top 10 da dificuldade "Normal"
SELECT TOP 10 u.username, r.pontuacao, r.nivel, r.linhas
FROM ranking r
JOIN usuarios u ON r.usuario_id = u.id
WHERE r.dificuldade = 'Normal'
ORDER BY r.pontuacao DESC;
```

---

## 🔐 SEGURANÇA

### Recomendações para apresentação na professora:

1. **Usar senha forte:**
   ```java
   private static final String PASSWORD = "Prof@123456";
   ```

2. **Se usar Azure/Cloud:**
   - Usar firewall para restringir IPs
   - Usar SSL/TLS (mude `encrypt=false` para `encrypt=true`)

3. **Never commit senhas no Git:**
   - Use variáveis de ambiente:
   ```java
   private static final String PASSWORD = System.getenv("DB_PASSWORD");
   ```

---

## 📋 CHECKLIST PARA APRESENTAÇÃO

- [ ] SQL Server está rodando (`localhost:1433`)
- [ ] Banco de dados `TetrisGame` foi criado
- [ ] Tabelas `usuarios` e `ranking` foram criadas
- [ ] Testei login/registro com DB funcionando
- [ ] Testei fallback (sem DB) com `users.txt`
- [ ] Consegui exportar rankings (CSV/HTML)
- [ ] Consegui ver Top 10 por dificuldade

---

## 🆘 TROUBLESHOOTING

| Problema | Solução |
|----------|---------|
| "Connection refused" | SQL Server não está rodando. Iniciar serviço ou usar Docker. |
| "Login failed for user 'sa'" | Verificar usuário/senha em DatabaseManager.java |
| "Cannot open database" | Banco 'TetrisGame' não existe. Criar via SSMS. |
| "Timeout" | Firewall bloqueando porta 1433. Abrir porta ou usar `encrypt=false`. |
| Sem SQL Server? | App automaticamente usa users.txt (fallback). |

---

## 📱 ALTERNATIVA: Usar MySQL

Se preferir MySQL ao invés de SQL Server:

1. Instalar MySQL: https://dev.mysql.com/downloads/mysql/
2. Adicionar driver em `pom.xml`:
   ```xml
   <dependency>
       <groupId>mysql</groupId>
       <artifactId>mysql-connector-java</artifactId>
       <version>8.0.33</version>
   </dependency>
   ```
3. Atualizar `DatabaseManager.java`:
   ```java
   private static final String DB_URL = "jdbc:mysql://localhost:3306/TetrisGame";
   private static final String USERNAME = "root";
   private static final String PASSWORD = "root";
   ```
4. Adaptar SQL para sintaxe MySQL (usar `AUTO_INCREMENT` em vez de `IDENTITY`)

---

## ✨ FLUXO FINAL

```
App inicia
   ↓
LoginDialog (AuthManager tenta DB)
   ├─ SQL Server conectado? → Usa DB
   └─ SQL Server offline? → Usa users.txt (fallback)
   ↓
User entra no jogo
   ↓
Partida salva em ranking (DB ou users.txt)
   ↓
RankingPanel mostra dados do DB
   ↓
ExportManager exporta para CSV/HTML
```

---

## 🎓 Para apresentar à professora:

1. **Mostrar a estrutura do banco:**
   ```powershell
   # Abrir SSMS e mostrar tabelas
   ```

2. **Mostrar dados sendo salvos:**
   - Jogar uma partida
   - Ir em "Ranking" e mostrar pontuação lá
   - Fazer query no SSMS para provar que está no DB

3. **Mostrar fallback funcionando:**
   - Desligar SQL Server
   - App continua funcionando com users.txt
   - Mostrar `users.txt` com hash das senhas

4. **Mostrar exportação:**
   - Clicar em "Statistics"
   - Exportar CSV/HTML
   - Abrir arquivo para provar

---

**Agora seu Tetris é um projeto profissional com banco de dados servidor! 🎮📊**

