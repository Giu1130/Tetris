package tetris.domain;

import java.awt.Color;

public class Tetromino {
    private boolean[][] forma;
    private final Color cor;
    private Posicao pos;

    public Tetromino(boolean[][] forma, Color cor, Posicao pos){
        this.forma = forma;
        this.cor = cor;
        this.pos = pos;
    }
    public boolean[][] getForma(){ return forma; }
    public Color getCor(){ return cor; }
    public Posicao getPos(){ return pos; }
    public void setPos(Posicao p){ this.pos = p; }

    public void moverEsquerda(){ this.pos = new Posicao(pos.x()-1, pos.y()); }
    public void moverDireita(){ this.pos = new Posicao(pos.x()+1, pos.y()); }
    public void moverBaixo(){ this.pos = new Posicao(pos.x(), pos.y()+1); }
    public void moverCima(){ this.pos = new Posicao(pos.x(), pos.y()-1); }

    public void rotacionarHorario(){
        int h = forma.length, w = forma[0].length;
        boolean[][] nova = new boolean[w][h];
        for(int r=0;r<h;r++) for(int c=0;c<w;c++) nova[c][h-1-r] = forma[r][c];
        forma = nova;
    }
}
