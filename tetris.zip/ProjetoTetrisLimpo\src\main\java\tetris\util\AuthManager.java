package tetris.util;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

public class AuthManager {
    private static final String USERS_FILE = "users.txt";

    public AuthManager() {
        // Initialize database on first use
        DatabaseManager.init();
    }

    public boolean userExists(String username) {
        // Try DB first if available
        if (isDbAvailable()) {
            String dbHash = DatabaseManager.getUserPassword(username);
            if (dbHash != null) return true;
        }
        // Fallback to file-based users
        return loadHashFromFile(username) != null;
    }

    public boolean register(String username, String password) {
        if (username == null || username.trim().isEmpty()) return false;
        if (password == null || password.isEmpty()) return false;
        if (userExists(username)) return false;
        String hash = hash(password);

        // Try to add to DB if available
        if (isDbAvailable()) {
            boolean success = DatabaseManager.addUser(username, hash);
            if (success) {
                // also persist to file as backup
                saveToFile(username, hash);
                return true;
            }
            // if DB add failed, fall through to file fallback
        }

        // Fallback: save to local file only
        return saveToFile(username, hash);
    }

    public boolean authenticate(String username, String password) {
        String expectedHash = null;
        // Try DB first
        if (isDbAvailable()) {
            expectedHash = DatabaseManager.getUserPassword(username);
            if (expectedHash != null) {
                return expectedHash.equals(hash(password));
            }
            // if DB available but user not found, we'll check file as fallback
        }

        // Fallback to file
        String fileHash = loadHashFromFile(username);
        return fileHash != null && fileHash.equals(hash(password));
    }

    private boolean saveToFile(String username, String hash) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(USERS_FILE, true))) {
            pw.printf("%s|%s%n", username, hash);
            return true;
        } catch (IOException e) {
            System.err.println("Erro ao salvar usuário em arquivo: " + e.getMessage());
            return false;
        }
    }

    private String loadHashFromFile(String username) {
        File f = new File(USERS_FILE);
        if (!f.exists()) return null;
        try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("\\|", 2);
                if (parts.length == 2) {
                    String u = parts[0];
                    String h = parts[1];
                    if (u.equals(username)) return h;
                }
            }
        } catch (IOException e) {
            System.err.println("Erro ao ler arquivo de usuários: " + e.getMessage());
        }
        return null;
    }

    private boolean isDbAvailable() {
        try {
            return DatabaseManager.getConnection() != null;
        } catch (Throwable t) {
            return false;
        }
    }

    private String hash(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] b = md.digest(s.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte by : b) sb.append(String.format("%02x", by));
            return sb.toString();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
