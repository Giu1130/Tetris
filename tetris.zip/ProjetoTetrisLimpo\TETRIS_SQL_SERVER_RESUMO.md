# 📊 TETRIS COM SQL SERVER - RESUMO FINAL

## ✅ O que foi implementado

Seu **Tetris Java** agora usa um **SQL Server profissional** como banco de dados, ao invés de arquivos locais.

### Mudança Principal:
```
❌ Antes: SQLite (tetris_game.db - arquivo local)
✅ Agora: SQL Server (servidor real em localhost:1433)
```

---

## 🗄️ BANCO DE DADOS SQL SERVER

### Localização:
- **Servidor:** `localhost` (seu computador)
- **Porta:** `1433` (padrão SQL Server)
- **Banco:** `TetrisGame`
- **Usuário:** `sa` (System Administrator)
- **Senha:** `YourPassword123!`

### Tabelas:

#### 1. `usuarios` (Armazena usuários + senhas)
```sql
┌─────────────────────────────────────────────────────────────┐
│                         usuarios                             │
├──────┬───────────────┬────────────────┬──────────────────────┤
│ id   │ username      │ password       │ data_criacao         │
├──────┼───────────────┼────────────────┼──────────────────────┤
│ 1    │ julia         │ a1b2c3d4e5...  │ 2025-01-12 10:30:00  │
│ 2    │ professor     │ x9y8z7w6v5...  │ 2025-01-12 11:45:00  │
└──────┴───────────────┴────────────────┴──────────────────────┘
```

#### 2. `ranking` (Armazena pontuações)
```sql
┌──────────────────────────────────────────────────────────────────┐
│                          ranking                                  │
├────┬──────────┬──────────┬──────┬────────┬──────────┬─────────────┤
│ id │usuario_id│pontuacao │nivel │linhas  │dificuldade│data_partida│
├────┼──────────┼──────────┼──────┼────────┼──────────┼─────────────┤
│ 1  │ 1        │ 5000     │ 10   │ 25     │ Normal   │ 2025-01-12  │
│ 2  │ 1        │ 8500     │ 15   │ 40     │ Difícil  │ 2025-01-12  │
│ 3  │ 2        │ 3200     │ 7    │ 15     │ Fácil    │ 2025-01-12  │
└────┴──────────┴──────────┴──────┴────────┴──────────┴─────────────┘
```

---

## 🚀 SETUP RÁPIDO (escolha uma opção)

### **OPÇÃO 1: Docker (Recomendado)** ⭐

```powershell
# Abrir PowerShell e rodar:
docker run -e "ACCEPT_EULA=Y" -e "SA_PASSWORD=YourPassword123!" `
  -p 1433:1433 `
  --name sqlserver-tetris `
  -d mcr.microsoft.com/mssql/server:latest

# Aguardar 30 segundos para SQL Server iniciar
Start-Sleep -Seconds 30
```

Depois, crie o banco com o script (veja abaixo).

### **OPÇÃO 2: SQL Server Express Local**

1. Baixar: https://www.microsoft.com/en-us/sql-server/sql-server-downloads
2. Escolher: **SQL Server Express Edition**
3. Instalar com:
   - Authentication: **SQL Server and Windows Authentication**
   - Senha do `sa`: **YourPassword123!**

Depois, crie o banco com o script (veja abaixo).

### **OPÇÃO 3: Script Automático**

```powershell
# No diretório do projeto (como ADMINISTRADOR):
.\setup-sqlserver.ps1
```

---

## 📝 Criar Banco de Dados

Execute este script SQL em qualquer ferramenta (SSMS, Azure Data Studio, etc):

```sql
CREATE DATABASE TetrisGame;
GO

USE TetrisGame;
GO

CREATE TABLE usuarios (
    id INT PRIMARY KEY IDENTITY(1,1),
    username NVARCHAR(100) UNIQUE NOT NULL,
    password NVARCHAR(256) NOT NULL,
    data_criacao DATETIME DEFAULT GETDATE()
);

CREATE TABLE ranking (
    id INT PRIMARY KEY IDENTITY(1,1),
    usuario_id INT NOT NULL,
    pontuacao INT NOT NULL,
    nivel INT NOT NULL,
    linhas INT NOT NULL,
    dificuldade NVARCHAR(50) NOT NULL,
    data_partida DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

PRINT 'Banco TetrisGame criado com sucesso!';
```

---

## ▶️ Executar o Jogo

```powershell
cd "c:\Users\Giulia Barros\Desktop\ProjetoTetrisLimpo"

# Compilar
mvn -DskipTests compile

# Executar
mvn -DskipTests exec:java
```

---

## 📋 Arquivos Modificados/Criados

### Modificados:
- **`src/main/java/tetris/util/DatabaseManager.java`**
  - Mudou de SQLite para SQL Server
  - Configuração: `localhost:1433`, usuário `sa`, senha `YourPassword123!`
  - Sintaxe SQL agora é para T-SQL (SQL Server)

- **`pom.xml`**
  - Já contém: `com.microsoft.sqlserver:mssql-jdbc:12.4.2.jre11`

### Criados:
- **`GUIA_SQL_SERVER.md`** - Guia completo com mais detalhes
- **`SQL_SERVER_QUICK_START.md`** - Quick start com instruções simples
- **`setup-sqlserver.ps1`** - Script PowerShell para automatizar setup
- **`RESUMO_IMPLEMENTACAO.md`** - Arquitetura completa do projeto

---

## 🔐 Segurança & Senhas

### Senhas de usuários:
- **Armazenadas como:** SHA-256 Hash (nunca em texto plano)
- **Exemplo:** `julia` → `9ac70...` (hash 64 caracteres)

### Credenciais do Banco:
- **Usuário:** `sa` (System Admin)
- **Senha:** `YourPassword123!`
- ⚠️ Para produção, usar senha mais forte

---

## 🧪 Testar Conexão

### No código:
```java
// DatabaseManager.java linha 6
private static final String SERVER = "localhost";
private static final int PORT = 1433;
private static final String DATABASE = "TetrisGame";
private static final String USERNAME = "sa";
private static final String PASSWORD = "YourPassword123!";
```

### Mensagens de sucesso:
```
✓ SQL Server database connected successfully!
✓ Tabelas verificadas/criadas com sucesso
```

### Se tiver erro:
```
✗ Não foi possível conectar ao SQL Server: ...
  Usando fallback para arquivo de usuários (users.txt)
```
→ App continua funcionando com fallback automático!

---

## 📊 Consultas Úteis no SQL Server

### Ver usuários cadastrados:
```sql
USE TetrisGame;
SELECT id, username, data_criacao FROM usuarios;
```

### Ver rankings:
```sql
SELECT TOP 10 
  u.username,
  r.pontuacao,
  r.dificuldade,
  r.data_partida
FROM ranking r
JOIN usuarios u ON r.usuario_id = u.id
ORDER BY r.dificuldade, r.pontuacao DESC;
```

### Limpar dados (teste):
```sql
DELETE FROM ranking;
DELETE FROM usuarios;
```

---

## 🎯 Fluxo da Aplicação

```
Usuário abre app
   ↓
Main.java → LoginDialog
   ↓
AuthManager tenta conectar ao SQL Server
   ├─ ✅ SQL Server disponível?
   │  └─ Usa DB para login/registro
   │
   └─ ❌ SQL Server offline?
      └─ Usa users.txt como fallback

Usuário faz login ✓
   ↓
Joga partida
   ↓
Game Over → Salva pontuação
   ├─ Se SQL disponível → ranking table (DB)
   └─ Se offline → users.txt

RankingPanel mostra top 10
   ├─ Se SQL disponível → busca do DB
   └─ Se offline → busca do arquivo

ExportManager exporta para CSV/HTML
```

---

## ✨ Recursos Implementados

- ✅ **Login/Registro** com SHA-256
- ✅ **Top 10 Rankings** por dificuldade
- ✅ **GIFs dinâmicos** (celebração vs game over)
- ✅ **Estatísticas dashboard**
- ✅ **Exportação CSV/HTML**
- ✅ **Banco SQL Server profissional**
- ✅ **Fallback automático** se DB offline
- ✅ **4 dificuldades:** Fácil, Normal, Difícil, Hardcore

---

## 🎓 Para Apresentar na Professora

### Mostrar:
1. **Estrutura do BD:**
   - Abrir SSMS
   - Mostrar tabelas `usuarios` e `ranking`
   - Executar queries para mostrar dados

2. **App funcionando:**
   - Fazer login
   - Jogar uma partida
   - Ver pontuação no ranking
   - Exportar dados para CSV/HTML

3. **Fallback resiliente:**
   - Desligar SQL Server
   - App continua funcionando
   - Mostrar dados em `users.txt`

---

## 📦 Estrutura de Pastas

```
ProjetoTetrisLimpo/
├── pom.xml                          (Maven + SQL Server driver)
├── GUIA_SQL_SERVER.md              (📍 Guia detalhado)
├── SQL_SERVER_QUICK_START.md       (📍 Quick start)
├── RESUMO_IMPLEMENTACAO.md         (📍 Arquitetura)
├── setup-sqlserver.ps1             (📍 Script de setup)
├── users.txt                        (Fallback local)
├── target/                          (Build Maven)
└── src/main/java/tetris/
    ├── Main.java
    ├── domain/                      (Lógica do jogo)
    ├── ui/                          (Interface Swing)
    ├── engine/                      (Input)
    └── util/
        └── DatabaseManager.java     (📍 Modificado para SQL Server)
```

---

## 🆘 Troubleshooting

| Problema | Solução |
|----------|---------|
| "Connection refused" | Iniciar SQL Server (Docker ou serviço) |
| "Login failed for user 'sa'" | Verificar usuário/senha em DatabaseManager.java |
| "Cannot open database 'TetrisGame'" | Criar banco com script SQL acima |
| App diz "usando fallback"? | Normal! Significa SQL offline mas app funciona |
| Quero MySQL em vez de SQL Server | Ver `GUIA_SQL_SERVER.md` - seção "Alternativa: MySQL" |

---

## 📞 Resumo para Entregar

**Seu projeto Tetris agora tem:**
- ✅ Jogo completo com mecânicas profissionais
- ✅ Interface Swing moderna com 4 dificuldades
- ✅ **Banco de dados SQL Server** em servidor (não arquivo)
- ✅ Login/Registro com segurança SHA-256
- ✅ Rankings e Estatísticas
- ✅ Exportação de dados (CSV/HTML)
- ✅ Resiliência (funciona com ou sem BD)

**Pronto para apresentação! 🎓🎮**

