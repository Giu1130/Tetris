package tetris.ui;

import tetris.util.RankingEntry;
import tetris.util.Ranking;

import javax.swing.*;
import java.awt.*;

public class RankingPanel extends JPanel {
    private Ranking ranking;
    private JFrame parentFrame;
    private JPanel listHolder;
    private JComboBox<String> cbDifficulty;

    public RankingPanel(JFrame parentFrame) {
        this.parentFrame = parentFrame;
        this.ranking = new Ranking();
        setBackground(TetrisColors.getBgDark());
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        initComponents();
    }

    private void initComponents() {
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel titleLabel = new JLabel("TOP 10");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 32));
        titleLabel.setForeground(TetrisColors.getAccent());
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(titleLabel);
        add(Box.createVerticalStrut(20));

        // Difficulty selector
        JPanel diffPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 0));
        diffPanel.setBackground(TetrisColors.getBgDark());
        JLabel diffLabel = new JLabel("Dificuldade:");
        diffLabel.setForeground(TetrisColors.getTextPrimary());
        diffLabel.setFont(TetrisColors.getLabelFont());
        String[] diffs = new String[]{"Fácil", "Normal", "Difícil", "Hardcore"};
        cbDifficulty = new JComboBox<>(diffs);
        cbDifficulty.setSelectedIndex(1);
        cbDifficulty.addActionListener(e -> refreshList((String)cbDifficulty.getSelectedItem()));
        diffPanel.add(diffLabel);
        diffPanel.add(cbDifficulty);
        diffPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(diffPanel);
        add(Box.createVerticalStrut(10));

        // Header
        JLabel headerLabel = new JLabel("POS. | JOGADOR | PONTOS | NÍVEL | LINHAS | DIFICULDADE");
        headerLabel.setFont(new Font("Courier New", Font.BOLD, 12));
        headerLabel.setForeground(TetrisColors.getAccent());
        headerLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(headerLabel);
        add(Box.createVerticalStrut(10));

        // Holder for ranking entries so we can refresh without rebuilding whole panel
        listHolder = new JPanel();
        listHolder.setLayout(new BoxLayout(listHolder, BoxLayout.Y_AXIS));
        listHolder.setBackground(TetrisColors.getBgDark());
        add(listHolder);

        // populate initial list
        refreshList((String)cbDifficulty.getSelectedItem());

        add(Box.createVerticalGlue());

        JButton backButton = new JButton("Voltar");
        backButton.setFont(new Font("Arial", Font.BOLD, 14));
        backButton.setBackground(TetrisColors.getAccent());
        backButton.setForeground(Color.WHITE);
        backButton.setFocusPainted(false);
        backButton.setMaximumSize(new Dimension(150, 40));
        backButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        backButton.addActionListener(e -> {
            if (parentFrame instanceof JFrame) {
                parentFrame.dispose();
            }
        });
        add(backButton);
    }

    public void addScore(RankingEntry entry) {
        ranking.addEntry(entry);
    }

    private void refreshList(String difficulty) {
        listHolder.removeAll();
        java.util.List<RankingEntry> top10 = ranking.getTop10(difficulty);
        if (top10.isEmpty()) {
            JLabel emptyLabel = new JLabel("Nenhuma pontuação registrada para " + difficulty);
            emptyLabel.setFont(new Font("Arial", Font.PLAIN, 14));
            emptyLabel.setForeground(TetrisColors.getTextSecondary());
            emptyLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
            listHolder.add(emptyLabel);
        } else {
            for (int i = 0; i < top10.size(); i++) {
                RankingEntry entry = top10.get(i);
                String position = String.format("%2d. ", i + 1);
                JLabel rankLabel = new JLabel(position + entry.toString());
                rankLabel.setFont(new Font("Courier New", Font.PLAIN, 12));
                rankLabel.setForeground(i == 0 ? TetrisColors.getAccent() : TetrisColors.getTextPrimary());
                rankLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
                listHolder.add(rankLabel);
                listHolder.add(Box.createVerticalStrut(5));
            }
        }
        listHolder.revalidate();
        listHolder.repaint();
    }
}
