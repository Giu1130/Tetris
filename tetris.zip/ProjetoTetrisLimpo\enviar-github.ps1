# ============================================
# Script para enviar projeto ao GitHub
# Baixa Git automaticamente se necessário
# ============================================

Write-Host "╔════════════════════════════════════════╗"
Write-Host "║  ENVIAR PROJETO AO GITHUB             ║"
Write-Host "╚════════════════════════════════════════╝" -ForegroundColor Cyan

# Verificar se é admin
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")
if (-not $isAdmin) {
    Write-Host "⚠️  Execute como ADMINISTRADOR!" -ForegroundColor Yellow
    Read-Host "Pressione ENTER"
    exit
}

# Verificar se Git está instalado
$gitPath = "C:\Program Files\Git\cmd\git.exe"
if (-not (Test-Path $gitPath)) {
    Write-Host "📥 Git não encontrado. Baixando..." -ForegroundColor Yellow
    
    # Baixar Git installer
    $gitInstaller = "$env:TEMP\GitInstaller.exe"
    Write-Host "Baixando Git..."
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    Invoke-WebRequest -Uri "https://github.com/git-for-windows/git/releases/download/v2.42.0.windows.1/Git-2.42.0-64-bit.exe" `
                      -OutFile $gitInstaller
    
    Write-Host "Instalando Git..."
    & $gitInstaller /VERYSILENT /NORESTART
    
    # Aguardar conclusão
    Start-Sleep -Seconds 10
    
    if (-not (Test-Path $gitPath)) {
        Write-Host "❌ Falha ao instalar Git" -ForegroundColor Red
        exit
    }
}

Write-Host "✓ Git encontrado!" -ForegroundColor Green

# Navegar para o projeto
cd "c:\Users\Giulia Barros\Desktop\ProjetoTetrisLimpo"

Write-Host "`n📋 Configurando repositório..." -ForegroundColor Cyan

# Configurar Git
& $gitPath config --global user.name "Giu1130"
& $gitPath config --global user.email "giubarros@email.com"

# Inicializar repositório
if (-not (Test-Path ".git")) {
    & $gitPath init
    Write-Host "✓ Repositório inicializado" -ForegroundColor Green
}

# Criar .gitignore
$gitignore = @"
target/
.classpath
.project
.settings/
*.db
users.txt
*.class
*.jar
.vscode/
*.pyc
__pycache__/
"@

$gitignore | Out-File -FilePath ".gitignore" -Encoding UTF8 -Force
Write-Host "✓ .gitignore criado" -ForegroundColor Green

# Adicionar remote
Write-Host "`n🔗 Conectando ao GitHub..." -ForegroundColor Cyan
& $gitPath remote remove origin 2>$null
& $gitPath remote add origin https://github.com/Giu1130/Tetris.git

# Adicionar arquivos
Write-Host "📦 Adicionando arquivos..." -ForegroundColor Cyan
& $gitPath add .
Write-Host "✓ Arquivos adicionados" -ForegroundColor Green

# Fazer commit
Write-Host "💾 Criando commit..." -ForegroundColor Cyan
& $gitPath commit -m "Tetris com SQL Server - Projeto Completo"
Write-Host "✓ Commit criado" -ForegroundColor Green

# Enviar para GitHub
Write-Host "`n🚀 Enviando para GitHub..." -ForegroundColor Cyan
Write-Host "⚠️  Se pedir autenticação:" -ForegroundColor Yellow
Write-Host "   1. Use seu USERNAME (Giu1130)"
Write-Host "   2. Para senha, gere um Personal Access Token:"
Write-Host "      GitHub → Settings → Developer settings → Personal access tokens"
Write-Host "   3. Crie novo token com permissão 'repo'"
Write-Host "   4. Cole o token como 'senha'" -ForegroundColor Yellow

& $gitPath push -u origin main

Write-Host "`n╔════════════════════════════════════════╗"
Write-Host "║  ✓ ENVIADO COM SUCESSO!              ║"
Write-Host "╚════════════════════════════════════════╝" -ForegroundColor Green

Write-Host "`n📱 Seu projeto está em:" -ForegroundColor Cyan
Write-Host "   https://github.com/Giu1130/Tetris"

Read-Host "`nPressione ENTER para finalizar"
