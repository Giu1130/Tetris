package tetris.ui;

import javax.swing.*;
import java.awt.*;
import java.util.List;
import tetris.domain.Tetromino;

public class NextPiecePanel extends JPanel {
    private List<Tetromino> proximas = List.of();

    public NextPiecePanel(){
        setPreferredSize(new Dimension(120, 160));
        setBackground(TetrisColors.getBgMedium());
        setBorder(BorderFactory.createLineBorder(TetrisColors.getAccent(), 2));
    }

    public void applyTheme() {
        setBackground(TetrisColors.getBgMedium());
        setBorder(BorderFactory.createLineBorder(TetrisColors.getAccent(), 2));
        repaint();
    }

    public void setQueue(List<Tetromino> list){
        this.proximas = list;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g){
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

    g2.setColor(TetrisColors.getAccent());
        g2.setFont(TetrisColors.getLabelFont());
        g2.drawString("PRÓXIMAS", 20, 18);

        if(proximas==null || proximas.isEmpty()) return;

        int startY = 30;
        int gap = 8;
        for(int i=0;i<proximas.size() && i<5;i++){
            Tetromino next = proximas.get(i);
            if(next==null) continue;
            boolean[][] f = next.getForma();
            int cell = 14;
            int offsetY = startY + i*(cell*2 + gap);
            g2.setColor(next.getCor());
            for(int r=0;r<f.length;r++){
                for(int c=0;c<f[r].length;c++){
                    if(f[r][c]){
                        int x = 30 + c*cell;
                        int y = offsetY + r*cell;
                        g2.fillRect(x, y, cell-1, cell-1);
                        g2.setColor(TetrisColors.BLOCK_BORDER);
                        g2.drawRect(x, y, cell-1, cell-1);
                        g2.setColor(next.getCor());
                    }
                }
            }
        }
    }
}
