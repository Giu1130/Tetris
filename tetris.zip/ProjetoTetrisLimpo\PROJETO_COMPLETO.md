# 🎮 TETRIS - Java 21 LTS | Projeto Completo

## ✅ Projeto Finalizado com Sucesso!

Seu jogo Tetris foi completamente desenvolvido com todas as funcionalidades solicitadas. Aqui está o resumo completo:

---

## 📋 Funcionalidades Implementadas

### 1. **Core Tetris Mechanics** ✓
- ✅ Peças (Tetrominoes) com 7 tipos diferentes (O, I, T, S, Z, J, L)
- ✅ Hold Piece: Segure uma peça para usar depois (1x por turno)
- ✅ Ghost Piece: Preview translúcido do local de pouso
- ✅ Next Queue: Fila de 5 próximas peças visíveis
- ✅ Soft Drop: Descer lentamente (1 ponto por célula)
- ✅ Hard Drop: Descer rapidamente (2 pontos por célula)
- ✅ Linha Completa: Detecta e limpa linhas automaticamente

### 2. **Gameplay Features** ✓
- ✅ **Timer**: Cronômetro em tempo real (mm:ss)
- ✅ **Dificuldade**: 3 níveis (Fácil 1.4x, Normal 1.0x, Difícil 0.7x)
- ✅ **Pausa**: Tecla P para pausar/resumir
- ✅ **Reiniciar**: Tecla R para nova partida
- ✅ **Velocidade**: Aumenta com cada nível (níveis ganhos a cada 10 linhas)

### 3. **Scoring System** ✓
- ✅ **Pontuação Clássica Tetris**:
  - 1 linha: 40 × nível
  - 2 linhas: 100 × nível
  - 3 linhas: 300 × nível
  - 4 linhas (Tetris): 1200 × nível
- ✅ Soft/Hard Drop bonuses
- ✅ Sistema de níveis (Nível = Linhas/10 + 1)

### 4. **Visual Design** ✓
- ✅ **Tema Clássico** (padrão): Azul escuro com vermelho vibrante
- ✅ **Tema Neon**: Cores vibrantes e futuristas
- ✅ **Tema Escuro**: Verde com tons cinza
- ✅ **Tema Retrô**: Cores vintage e acessíveis
- ✅ **Seletor de Tema**: Mude o tema durante o jogo
- ✅ **Fonts Estilizadas**: Courier New para números, Arial para interface
- ✅ **3-Panel Layout**:
  - Esquerda: Hold + Score
  - Centro: Game Board
  - Direita: Next Pieces

### 5. **Player Features** ✓
- ✅ **Nome do Jogador**: Diálogo de entrada antes de começar
- ✅ **Ranking Persistente**: Top 10 salvo em `ranking.txt`
  - Armazena: Nome, Pontuação, Nível, Linhas, Dificuldade
  - Ordenação automática por pontuação (descendente)
- ✅ **Leaderboard**: Visualize top 10 a qualquer hora (botão Ranking)

### 6. **Celebração & Feedback** ✓
- ✅ **Game Over Dialog**:
  - GIF Cellbit rindo (quando perde)
  - Mostra: Jogador, Pontuação, Nível, Linhas
- ✅ **High Score Dialog**:
  - GIF Cellbit Poggers (ao bater recorde)
  - Emoji 🎉 e estética especial
  - Salva automaticamente no ranking

---

## 🏗️ Arquitetura do Projeto

```
tetris/
├── domain/
│   ├── Jogador.java          (Informações do jogador)
│   ├── Partida.java          (Lógica do jogo + fila de peças)
│   ├── Tabuleiro.java        (Grid 10x20 + colisões)
│   ├── Posicao.java          (Coordenadas)
│   ├── SistemaPontuacao.java (Scoring e níveis)
│   ├── Tetromino.java        (Peças)
│   └── TetrominoFactory.java (Gerador de peças)
│
├── ui/
│   ├── TelaPrincipal.java    (Janela principal + controles)
│   ├── GamePanel.java        (Renderização do tabuleiro)
│   ├── ScorePanel.java       (Placar, timer, status)
│   ├── NextPiecePanel.java   (Fila de 5 próximas peças)
│   ├── HoldPanel.java        (Peça segura)
│   ├── PlayerNameDialog.java (Entrada de nome)
│   ├── RankingPanel.java     (Leaderboard)
│   ├── GameOverDialog.java   (Tela com GIFs - NOVO!)
│   ├── TetrisColors.java     (Cores dinâmicas)
│   └── TetrisTheme.java      (4 temas customizáveis)
│
├── engine/
│   └── InputHandler.java     (Controle de teclado)
│
├── util/
│   ├── RankingEntry.java     (Dados de ranking)
│   ├── Ranking.java          (Gerenciador de ranking)
│   └── GifLoader.java        (Carregamento de GIFs)
│
└── Main.java                 (Entrada + inicialização)
```

---

## 🎮 Como Jogar

### Controles:
- **↑/↓/←/→**: Mover peça
- **Z/X**: Rotacionar
- **C**: Hold (segura peça)
- **Down**: Soft Drop (1 ponto/célula)
- **Space**: Hard Drop (2 pontos/célula)
- **P**: Pausar/Resumir
- **R**: Reiniciar partida
- **Botão Ranking**: Ver leaderboard

### Objetivo:
1. Completar linhas horizontais
2. Alcançar a maior pontuação possível
3. Subir no ranking e comemorar com o Cellbit! 🎉

---

## 🚀 Como Executar

### Opção 1: JAR compilado
```powershell
java -jar target/ProjetoTetrisLimpo-1.0-SNAPSHOT.jar
```

### Opção 2: Maven direto
```powershell
mvn clean compile exec:java -Dexec.mainClass="tetris.Main"
```

### Opção 3: Compilar e rodar
```powershell
mvn clean package -DskipTests
java -jar target/ProjetoTetrisLimpo-1.0-SNAPSHOT.jar
```

---

## 💾 Dados Persistentes

**Arquivo de Ranking**: `ranking.txt` (criado na pasta do projeto)

Formato:
```
Giulia|2500|5|25|Normal
João|1800|3|18|Fácil
Maria|3200|6|32|Normal
```

---

## 🎨 Temas Disponíveis

| Tema | Cor Primária | Cor Fundo | Ambiente |
|------|-------------|----------|----------|
| **Clássico** | Vermelho (#FF4444) | Azul escuro (#1a1a2e) | Original |
| **Neon** | Magenta (#FF00FF) | Preto (#0a0e27) | Futurista |
| **Escuro** | Verde (#00CC00) | Cinza (#1a1a1a) | Moderno |
| **Retrô** | Laranja (#E74C3C) | Cinza (#2c3e50) | Vintage |

---

## 🔧 Detalhes Técnicos

### Stack Tecnológico:
- **Java**: 21 LTS
- **Build**: Maven 3.x
- **UI**: Swing (JFrame, JPanel, Graphics2D)
- **Persistência**: File I/O (texto)
- **GIFs**: Carregamento de URLs (Tenor)

### Compilação:
```xml
<release>21</release>
<source>21</source>
<target>21</target>
```

### Construção Verificada:
✅ 22 arquivos Java compilados
✅ 0 erros, 0 avisos críticos
✅ JAR executável gerado
✅ BUILD SUCCESS

---

## 📊 Estatísticas do Projeto

| Métrica | Valor |
|---------|-------|
| **Arquivos Java** | 22 |
| **Linhas de Código** | ~2000+ |
| **Classes** | 22 |
| **Recursos UI** | 8 painéis |
| **Temas** | 4 |
| **Teclas de Controle** | 11 |
| **GIFs de Celebração** | 2 |

---

## 🎯 Funcionalidades Extras Implementadas

1. **Sistema de Temas Dinâmicos**: Mude o tema a qualquer momento
2. **Ranking Persistente**: Seus scores são salvos automaticamente
3. **High Score Detection**: Detecta novos recordes e celebra! 🎉
4. **GIFs Animados**: Cellbit reage ao seu desempenho
5. **Dialogo Customizado**: Game Over com estilo profissional

---

## 🏆 Próximas Melhorias (Opcionais)

- [ ] Modo Multiplayer local
- [ ] Efeitos sonoros
- [ ] Replay de partidas
- [ ] Achievements/Badges
- [ ] Estatísticas detalhadas
- [ ] Modo Survival/Time Attack
- [ ] Customização de cores por jogador

---

## 📝 Notas Importantes

✅ **Tudo Funcionando**: Todas as features foram testadas
✅ **Java 21 Ready**: Usa features modernas (switch expressions, records)
✅ **Sem Dependências Externas**: Apenas Java padrão + URLs para GIFs
✅ **Cross-Platform**: Funciona em Windows, Mac, Linux (com Java 21)

---

## 👾 Créditos

- **Desenvolvedor**: GitHub Copilot + Você
- **Celebrações**: GIFs do Cellbit via Tenor
- **Inspiração**: Tetris Clássico NES
- **Tech**: Java 21 LTS, Swing, Maven

---

**Aproveite o seu Tetris! E que os GIFs do Cellbit te tragam sorte! 🎮🎉**

---

*Última atualização: Novembro 11, 2025 | Build: 3.098s | Status: ✅ COMPLETO*
