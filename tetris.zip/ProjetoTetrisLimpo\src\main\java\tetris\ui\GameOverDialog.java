package tetris.ui;

import javax.swing.*;
import java.awt.*;
import tetris.util.GifLoader;
import tetris.util.RankingEntry;
import tetris.util.Ranking;

public class GameOverDialog extends JDialog {
    private boolean isNewHighScore = false;
    private boolean isRankImprovement = false;
    private RankingEntry entry;

    // isFinal: true when triggered by actual game over; false when user clicked "Parar & Registrar"
    public GameOverDialog(JFrame parent, int score, int level, int lines, String playerName, String difficulty, boolean isFinal) {
        super(parent, "GAME OVER", true);
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        setResizable(false);
        
    // Check if it's a new high score or rank improvement
    Ranking ranking = new Ranking();
        
        this.entry = new RankingEntry(playerName, score, level, lines, difficulty);
        
        // Determine existing personal record for this player and difficulty
        RankingEntry existingPersonal = null;
        for (RankingEntry e : ranking.getTop10()) {
            if (e.playerName.equals(playerName) && e.difficulty != null && e.difficulty.equalsIgnoreCase(difficulty)) {
                existingPersonal = e;
                break;
            }
        }

        // Personal new high score only if we have a previous personal record and current score is higher
        if (existingPersonal != null && score > existingPersonal.score) {
            isNewHighScore = true;
        } else {
            isNewHighScore = false;
        }

        // Determine if this score would enter top10 for this difficulty
        java.util.List<RankingEntry> topForDifficulty = ranking.getTop10(difficulty);
        boolean wouldEnterTop10 = false;
        if (topForDifficulty.size() < 10) {
            wouldEnterTop10 = true;
        } else {
            RankingEntry last = topForDifficulty.get(topForDifficulty.size() - 1);
            if (score > last.score) wouldEnterTop10 = true;
        }

        if (isNewHighScore || wouldEnterTop10) {
            isRankImprovement = true;
            ranking.addEntry(entry);
        } else {
            isRankImprovement = false;
        }
        
        initComponents(score, level, lines, playerName, isFinal);
        setLocationRelativeTo(parent);
    }

    private void initComponents(int score, int level, int lines, String playerName, boolean isFinal) {
        JPanel mainPanel = new JPanel();
        mainPanel.setBackground(TetrisColors.getBgDark());
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // Title: show 'NOVO RECORD' only when it's a true new record. When dialog is opened via manual Stop,
        // use a neutral "REGISTRO" title unless there is a new record.
        String titleText;
        Color titleColor;
        if (isFinal) {
            if (isNewHighScore) {
                titleText = "NOVO RECORD!";
                titleColor = new Color(0xFFD700); // Ouro
            } else if (isRankImprovement) {
                titleText = "MELHOROU DE RANK!";
                titleColor = new Color(0x00FF00); // Verde
            } else {
                titleText = "GAME OVER";
                titleColor = TetrisColors.getAccent();
            }
        } else {
            // manual registration dialog
            if (isNewHighScore) {
                titleText = "NOVO RECORD!";
                titleColor = new Color(0xFFD700);
            } else {
                titleText = "REGISTRO";
                titleColor = TetrisColors.getAccent();
            }
        }
        
        JLabel titleLabel = new JLabel(titleText);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 32));
        titleLabel.setForeground(titleColor);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(titleLabel);
        mainPanel.add(Box.createVerticalStrut(15));

        // GIF - Poggers se subiu de rank, sad caso contrário
        ImageIcon gifIcon;
        if (isRankImprovement) {
            gifIcon = GifLoader.getHighScoreGif(); // Poggers
        } else {
            gifIcon = GifLoader.getGameOverGif(); // Sad
        }
        
        if (gifIcon != null) {
            JLabel gifLabel = new JLabel(gifIcon);
            gifLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
            mainPanel.add(gifLabel);
            mainPanel.add(Box.createVerticalStrut(15));
        } else {
            // fallback: mostrar ícone do app ou texto informativo
            javax.swing.ImageIcon appIcon = tetris.util.ImageLoader.getAppIcon();
            if (appIcon != null) {
                JLabel iconLabel = new JLabel(appIcon);
                iconLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
                mainPanel.add(iconLabel);
                mainPanel.add(Box.createVerticalStrut(10));
            }
            JLabel noGif = new JLabel("(GIF indisponível)");
            noGif.setFont(new Font("Arial", Font.ITALIC, 12));
            noGif.setForeground(TetrisColors.getTextSecondary());
            noGif.setAlignmentX(Component.CENTER_ALIGNMENT);
            mainPanel.add(noGif);
            mainPanel.add(Box.createVerticalStrut(10));
        }

        // Stats
        JPanel statsPanel = new JPanel();
        statsPanel.setBackground(TetrisColors.getBgDark());
        statsPanel.setLayout(new BoxLayout(statsPanel, BoxLayout.Y_AXIS));
        statsPanel.setMaximumSize(new Dimension(300, 150));

        JLabel playerLabel = new JLabel("Jogador: " + playerName);
        playerLabel.setFont(TetrisColors.getScoreFont());
        playerLabel.setForeground(TetrisColors.getTextPrimary());
        playerLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        statsPanel.add(playerLabel);

        JLabel scoreLabel = new JLabel("Pontuação: " + score);
        scoreLabel.setFont(TetrisColors.getScoreFont());
        scoreLabel.setForeground(TetrisColors.getAccent());
        scoreLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        statsPanel.add(scoreLabel);

        JLabel levelLabel = new JLabel("Nível: " + level);
        levelLabel.setFont(TetrisColors.getScoreFont());
        levelLabel.setForeground(TetrisColors.getTextPrimary());
        levelLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        statsPanel.add(levelLabel);

        JLabel linesLabel = new JLabel("Linhas: " + lines);
        linesLabel.setFont(TetrisColors.getScoreFont());
        linesLabel.setForeground(TetrisColors.getTextPrimary());
        linesLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        statsPanel.add(linesLabel);

        statsPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(statsPanel);
        mainPanel.add(Box.createVerticalStrut(20));

        // Button
        JButton closeButton = new JButton("OK");
        closeButton.setFont(TetrisColors.getLabelFont());
        closeButton.setBackground(TetrisColors.getAccent());
        closeButton.setForeground(Color.WHITE);
        closeButton.setFocusPainted(false);
        closeButton.setMaximumSize(new Dimension(120, 40));
        closeButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        closeButton.addActionListener(e -> {
            setVisible(false);
            dispose();
        });
        mainPanel.add(closeButton);

        setContentPane(mainPanel);
        setSize(450, isNewHighScore ? 700 : 650);
    }

    public boolean isNewHighScore() {
        return isNewHighScore;
    }
}
