# Script para baixar os GIFs do Cellbit automaticamente

# URLs dos GIFs
$gameoverUrl = "https://media.tenor.com/qzZT5n_pG2kAAAAM/cellbit-cat.gif"
$highscoreUrl = "https://media.tenor.com/CjISuqLbCfYAAAAM/cellbit-poggers.gif"

# Pasta de destino
$gifFolder = "src\main\resources\gifs"

# Criar pasta se não existir
if (!(Test-Path $gifFolder)) {
    New-Item -ItemType Directory -Force -Path $gifFolder | Out-Null
    Write-Host "✓ Pasta criada: $gifFolder" -ForegroundColor Green
}

# Baixar GIF de Game Over
$gameoverPath = "$gifFolder\gameovergif.gif"
if (!(Test-Path $gameoverPath)) {
    Write-Host "Baixando gameovergif.gif..." -ForegroundColor Yellow
    try {
        $WebClient = New-Object System.Net.WebClient
        $WebClient.DownloadFile($gameoverUrl, $gameoverPath)
        Write-Host "✓ gameovergif.gif baixado com sucesso!" -ForegroundColor Green
    } catch {
        Write-Host "✗ Erro ao baixar gameovergif.gif: $_" -ForegroundColor Red
    }
} else {
    Write-Host "✓ gameovergif.gif já existe" -ForegroundColor Green
}

# Baixar GIF de High Score
$highscorePath = "$gifFolder\highscoregif.gif"
if (!(Test-Path $highscorePath)) {
    Write-Host "Baixando highscoregif.gif..." -ForegroundColor Yellow
    try {
        $WebClient = New-Object System.Net.WebClient
        $WebClient.DownloadFile($highscoreUrl, $highscorePath)
        Write-Host "✓ highscoregif.gif baixado com sucesso!" -ForegroundColor Green
    } catch {
        Write-Host "✗ Erro ao baixar highscoregif.gif: $_" -ForegroundColor Red
    }
} else {
    Write-Host "✓ highscoregif.gif já existe" -ForegroundColor Green
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "GIFs prontos! Agora execute:" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "mvn clean -q" -ForegroundColor Yellow
Write-Host "mvn -DskipTests package -q" -ForegroundColor Yellow
Write-Host "mvn exec:java" -ForegroundColor Yellow
Write-Host ""
