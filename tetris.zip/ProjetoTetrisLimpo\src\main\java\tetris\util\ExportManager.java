package tetris.util;

import java.io.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class ExportManager {
    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public static void exportRankingToCSV(String dificuldade, String fileName) {
        ResultSet rs = DatabaseManager.getTop10(dificuldade);
        
        try (PrintWriter writer = new PrintWriter(new FileWriter(fileName))) {
            // Header
            writer.println("Posição,Jogador,Pontuação,Nível,Linhas,Novo Record,Data");
            
            int position = 1;
            if (rs != null) {
                while (rs.next()) {
                    String username = rs.getString("Username");
                    int pontuacao = rs.getInt("Pontuacao");
                    int nivel = rs.getInt("Nivel");
                    int linhas = rs.getInt("Linhas");
                    boolean novoRecord = rs.getBoolean("SuprouRecord");
                    String data = rs.getString("DataPartida");
                    
                    writer.printf("%d,\"%s\",%d,%d,%d,%s,%s%n",
                            position++,
                            username,
                            pontuacao,
                            nivel,
                            linhas,
                            novoRecord ? "SIM" : "NÃO",
                            data);
                }
            }
            
            System.out.println("✓ Ranking exportado para CSV: " + fileName);
        } catch (IOException | SQLException e) {
            System.err.println("✗ Erro ao exportar CSV: " + e.getMessage());
        }
    }

    public static void exportRankingToHTML(String dificuldade, String fileName) {
        ResultSet rs = DatabaseManager.getTop10(dificuldade);
        
        try (PrintWriter writer = new PrintWriter(new FileWriter(fileName))) {
            // HTML Header
            writer.println("<!DOCTYPE html>");
            writer.println("<html lang=\"pt-BR\">");
            writer.println("<head>");
            writer.println("    <meta charset=\"UTF-8\">");
            writer.println("    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">");
            writer.println("    <title>Ranking TETRIS - " + dificuldade + "</title>");
            writer.println("    <style>");
            writer.println("        body { font-family: Arial, sans-serif; background: #0f0f1e; color: white; margin: 20px; }");
            writer.println("        h1 { text-align: center; color: #00d4ff; text-shadow: 0 0 10px #00d4ff; }");
            writer.println("        table { width: 100%; border-collapse: collapse; margin-top: 20px; background: #1a1a2e; }");
            writer.println("        th, td { padding: 12px; text-align: left; border-bottom: 2px solid #00d4ff; }");
            writer.println("        th { background: #0066cc; font-weight: bold; }");
            writer.println("        tr:hover { background: #2a2a3e; }");
            writer.println("        .record { color: #ffff00; font-weight: bold; }");
            writer.println("        .footer { text-align: center; margin-top: 30px; color: #666; }");
            writer.println("    </style>");
            writer.println("</head>");
            writer.println("<body>");
            writer.println("    <h1>🎮 RANKING TETRIS - " + dificuldade.toUpperCase() + "</h1>");
            writer.println("    <table>");
            writer.println("        <thead>");
            writer.println("            <tr>");
            writer.println("                <th>Posição</th>");
            writer.println("                <th>Jogador</th>");
            writer.println("                <th>Pontuação</th>");
            writer.println("                <th>Nível</th>");
            writer.println("                <th>Linhas</th>");
            writer.println("                <th>Novo Record</th>");
            writer.println("                <th>Data</th>");
            writer.println("            </tr>");
            writer.println("        </thead>");
            writer.println("        <tbody>");
            
            int position = 1;
            if (rs != null) {
                while (rs.next()) {
                    String username = rs.getString("Username");
                    int pontuacao = rs.getInt("Pontuacao");
                    int nivel = rs.getInt("Nivel");
                    int linhas = rs.getInt("Linhas");
                    boolean novoRecord = rs.getBoolean("SuprouRecord");
                    String data = rs.getString("DataPartida");
                    
                    String recordClass = novoRecord ? " class=\"record\"" : "";
                    writer.println("            <tr>");
                    writer.printf("                <td>%d</td>%n", position++);
                    writer.printf("                <td>%s</td>%n", username);
                    writer.printf("                <td%s>%,d</td>%n", recordClass, pontuacao);
                    writer.printf("                <td>%d</td>%n", nivel);
                    writer.printf("                <td>%d</td>%n", linhas);
                    writer.printf("                <td%s>%s</td>%n", recordClass, novoRecord ? "✓ SIM" : "✗ NÃO");
                    writer.printf("                <td>%s</td>%n", data);
                    writer.println("            </tr>");
                }
            }
            
            writer.println("        </tbody>");
            writer.println("    </table>");
            writer.println("    <div class=\"footer\">");
            writer.printf("        <p>Gerado em: %s</p>%n", LocalDateTime.now().format(formatter));
            writer.println("    </div>");
            writer.println("</body>");
            writer.println("</html>");
            
            System.out.println("✓ Ranking exportado para HTML: " + fileName);
        } catch (IOException | SQLException e) {
            System.err.println("✗ Erro ao exportar HTML: " + e.getMessage());
        }
    }

    public static void exportAllDifficulties(String outputDir) {
        String[] difficulties = {"Fácil", "Normal", "Difícil", "Hardcore"};
        
        for (String diff : difficulties) {
            String csvName = outputDir + File.separator + "ranking_" + diff.toLowerCase() + ".csv";
            String htmlName = outputDir + File.separator + "ranking_" + diff.toLowerCase() + ".html";
            
            exportRankingToCSV(diff, csvName);
            exportRankingToHTML(diff, htmlName);
        }
        
        System.out.println("✓ Todos os rankings foram exportados para: " + outputDir);
    }
}
