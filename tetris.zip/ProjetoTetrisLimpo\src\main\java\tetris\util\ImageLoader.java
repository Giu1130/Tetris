package tetris.util;

import javax.swing.ImageIcon;
import java.net.URL;

public class ImageLoader {
    private static ImageIcon tetrisLogo;
    private static ImageIcon appIcon;

    public static ImageIcon getTetrisLogo() {
        if (tetrisLogo == null) {
            try {
                URL url = ImageLoader.class.getClassLoader().getResource("images/tetris_logo.png");
                if (url != null) {
                    tetrisLogo = new ImageIcon(url);
                }
            } catch (Exception e) {
                System.err.println("Erro ao carregar logo: " + e.getMessage());
            }
        }
        return tetrisLogo;
    }

    public static ImageIcon getAppIcon() {
        if (appIcon == null) {
            try {
                URL url = ImageLoader.class.getClassLoader().getResource("images/tetris_logo.png");
                if (url != null) {
                    appIcon = new ImageIcon(url);
                }
            } catch (Exception e) {
                System.err.println("Erro ao carregar icon: " + e.getMessage());
            }
        }
        return appIcon;
    }
}