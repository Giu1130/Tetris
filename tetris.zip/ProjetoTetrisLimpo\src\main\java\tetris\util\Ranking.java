package tetris.util;

import java.io.*;
import java.util.*;

public class Ranking {
    private static final String RANKING_FILE = "ranking.txt";
    private List<RankingEntry> entries = new ArrayList<>();

    public Ranking() {
        load();
    }

    public void addEntry(RankingEntry entry) {
        // Only compare/replace entries within the same difficulty
        RankingEntry existing = null;
        for (RankingEntry e : entries) {
            if (e.playerName.equals(entry.playerName) && e.difficulty.equals(entry.difficulty)) {
                existing = e;
                break;
            }
        }
        if (existing != null) {
            if (entry.score <= existing.score) {
                // nothing to do - current saved entry is better or equal for this difficulty
                return;
            } else {
                // remove older/weaker entry and replace
                entries.remove(existing);
            }
        }
        entries.add(entry);
        // keep file consistent but do not limit global entries here; getTop10 will filter and slice
        Collections.sort(entries);
        save();
    }

    public List<RankingEntry> getTop10() {
        // default: return top 10 across all difficulties (kept for compatibility)
        List<RankingEntry> copy = new ArrayList<>(entries);
        Collections.sort(copy);
        if (copy.size() > 10) return copy.subList(0, 10);
        return copy;
    }

    /**
     * Return top 10 entries filtered by difficulty (exact match on difficulty string).
     */
    public List<RankingEntry> getTop10(String difficulty) {
        List<RankingEntry> filtered = new ArrayList<>();
        for (RankingEntry e : entries) {
            if (e.difficulty != null && e.difficulty.equalsIgnoreCase(difficulty)) {
                filtered.add(e);
            }
        }
        Collections.sort(filtered);
        if (filtered.size() > 10) return filtered.subList(0, 10);
        return filtered;
    }

    private void load() {
        File file = new File(RANKING_FILE);
        if (!file.exists()) return;

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("\\|");
                if (parts.length >= 5) {
                    entries.add(new RankingEntry(
                        parts[0].trim(),
                        Integer.parseInt(parts[1].trim()),
                        Integer.parseInt(parts[2].trim()),
                        Integer.parseInt(parts[3].trim()),
                        parts[4].trim()
                    ));
                }
            }
            Collections.sort(entries);
        } catch (IOException e) {
            System.err.println("Erro ao carregar ranking: " + e.getMessage());
        }
    }

    private void save() {
        try (PrintWriter pw = new PrintWriter(new FileWriter(RANKING_FILE))) {
            for (RankingEntry entry : entries) {
                pw.printf("%s|%d|%d|%d|%s%n", entry.playerName, entry.score, entry.level, entry.lines, entry.difficulty);
            }
        } catch (IOException e) {
            System.err.println("Erro ao salvar ranking: " + e.getMessage());
        }
    }
}
