package tetris;

import javax.swing.*;
import tetris.domain.Jogador;
import tetris.domain.Partida;
import tetris.ui.TelaPrincipal;
import tetris.ui.LoginDialog;
import tetris.ui.TetrisTheme;
import tetris.util.AuthManager;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            // Load default theme
            TetrisTheme.setTheme(TetrisTheme.ThemeName.CLASSIC);
            
            // Show login dialog (with register)
            AuthManager auth = new AuthManager();
            JFrame tempFrame = new JFrame();
            tempFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            tempFrame.setVisible(false);  // Keep it hidden, only used as parent for dialogs
            
            LoginDialog login = new LoginDialog(tempFrame, auth);
            login.setVisible(true);
            if (!login.isConfirmed() || login.getUsername() == null) {
                tempFrame.dispose();
                System.exit(0);
            }
            
            Jogador jogador = new Jogador(login.getUsername());
            Partida partida = new Partida(jogador);
            TelaPrincipal tela = new TelaPrincipal(partida);
            tela.iniciar();
            tempFrame.dispose();
        });
    }
}
