package tetris.domain;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class Partida {
    private final Jogador jogador;
    private final Tabuleiro tab;
    private final SistemaPontuacao score;
    private Tetromino atual;
    private Tetromino proxima;
    private final LinkedList<Tetromino> fila = new LinkedList<>();
    private Tetromino segurada = null; // hold piece
    private boolean holdUsada = false;
    private boolean gameOver = false;

    public Partida(Jogador j){
        this.jogador = j;
        this.tab = new Tabuleiro();
        this.score = new SistemaPontuacao();
        // preencher fila inicial com 5 peças
        for(int i=0;i<5;i++) fila.add(TetrominoFactory.criarAleatorio(4, -2));
        this.atual = fila.pollFirst();
        this.proxima = fila.peekFirst();
    }

    public Jogador getJogador(){ return jogador; }

    public Tabuleiro getTabuleiro(){ return tab; }
    public SistemaPontuacao getScore(){ return score; }
    public Tetromino getAtual(){ return atual; }
    public Tetromino getProxima(){ return proxima; }
    public boolean isGameOver(){ return gameOver; }

    public List<Tetromino> getNextQueue(){ return Collections.unmodifiableList(fila); }
    public Tetromino getSegurada(){ return segurada; }

    public void tickDrop(){
        atual.moverBaixo();
        if(!tab.posicaoValida(atual)){
            atual.moverCima();
            tab.fixarPeca(atual);
            int l = tab.eliminarLinhasCompletas();
            score.adicionarLinhas(l);
            // puxar próxima da fila e repor
            fila.add(TetrominoFactory.criarAleatorio(4, -2));
            atual = fila.pollFirst();
            proxima = fila.peekFirst();
            holdUsada = false; // permitir hold novamente
            if(!tab.posicaoValida(atual)) gameOver = true;
        }
    }

    public void moveLeft(){
        atual.moverEsquerda();
        if(!tab.posicaoValida(atual)) atual.moverDireita();
    }
    public void moveRight(){
        atual.moverDireita();
        if(!tab.posicaoValida(atual)) atual.moverEsquerda();
    }
    public void rotate(){
        atual.rotacionarHorario();
        if(!tab.posicaoValida(atual)){
            // tentar wall-kick simples: mover uma coluna esquerda/direita
            atual.moverEsquerda();
            if(!tab.posicaoValida(atual)){
                atual.moverDireita(); atual.moverDireita();
                if(!tab.posicaoValida(atual)) atual.moverEsquerda(); // volta
            }
        }
    }

    public void hardDrop(){
        int steps = 0;
        while(true){
            atual.moverBaixo();
            if(!tab.posicaoValida(atual)){
                atual.moverCima();
                tab.fixarPeca(atual);
                int l = tab.eliminarLinhasCompletas();
                score.adicionarLinhas(l);
                score.adicionarHardDrop(steps);
                // atualizar fila
                fila.add(TetrominoFactory.criarAleatorio(4, -2));
                atual = fila.pollFirst();
                proxima = fila.peekFirst();
                holdUsada = false;
                if(!tab.posicaoValida(atual)) gameOver = true;
                break;
            }
            steps++;
        }
    }

    public void softDrop(){
        atual.moverBaixo();
        if(!tab.posicaoValida(atual)){
            atual.moverCima();
            tab.fixarPeca(atual);
            int l = tab.eliminarLinhasCompletas();
            score.adicionarLinhas(l);
            fila.add(TetrominoFactory.criarAleatorio(4, -2));
            atual = fila.pollFirst();
            proxima = fila.peekFirst();
            holdUsada = false;
            if(!tab.posicaoValida(atual)) gameOver = true;
        } else {
            score.adicionarSoftDrop(1);
        }
    }

    public void hold(){
        if(holdUsada) return;
        if(segurada == null){
            segurada = new Tetromino(atual.getForma(), atual.getCor(), new Posicao(4, -2));
            // repor atual
            fila.add(TetrominoFactory.criarAleatorio(4, -2));
            atual = fila.pollFirst();
            proxima = fila.peekFirst();
        } else {
            Tetromino temp = segurada;
            segurada = new Tetromino(atual.getForma(), atual.getCor(), new Posicao(4, -2));
            atual = new Tetromino(temp.getForma(), temp.getCor(), new Posicao(4, -2));
            proxima = fila.peekFirst();
        }
        holdUsada = true;
        if(!tab.posicaoValida(atual)) gameOver = true;
    }
}
