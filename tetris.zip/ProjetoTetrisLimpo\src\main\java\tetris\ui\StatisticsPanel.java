package tetris.ui;

import tetris.util.DatabaseManager;

import javax.swing.*;
import tetris.util.ExportManager;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.ResultSet;
import java.sql.SQLException;

public class StatisticsPanel extends JFrame {
    private JTable rankingTable;
    private JComboBox<String> difficultyCombo;
    private JLabel statsLabel;

    public StatisticsPanel() {
        setTitle("Estatísticas - TETRIS");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(900, 600);
        setLocationRelativeTo(null);
        setResizable(true);

        JPanel mainPanel = new JPanel();
        mainPanel.setBackground(TetrisColors.getBgDark());
        mainPanel.setLayout(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // Header
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(TetrisColors.getBgDark());
        headerPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));

        JLabel titleLabel = new JLabel("📊 RANKING GERAL");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(TetrisColors.getAccent());
        headerPanel.add(titleLabel);

        // Difficulty Selector
        JLabel diffLabel = new JLabel("Dificuldade:");
        diffLabel.setForeground(Color.WHITE);
        diffLabel.setFont(new Font("Arial", Font.BOLD, 14));
        headerPanel.add(diffLabel);

        difficultyCombo = new JComboBox<>(new String[]{"Fácil", "Normal", "Difícil", "Hardcore"});
        difficultyCombo.setBackground(TetrisColors.getAccent());
        difficultyCombo.setForeground(Color.WHITE);
        difficultyCombo.addActionListener(e -> loadRanking());
        headerPanel.add(difficultyCombo);

        mainPanel.add(headerPanel, BorderLayout.NORTH);

        // Export Buttons Panel
        JPanel exportPanel = new JPanel();
        exportPanel.setBackground(TetrisColors.getBgDark());
        exportPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 5));
        
        JButton btnExportCSV = new JButton("💾 Exportar CSV");
        btnExportCSV.setBackground(new Color(0x4CAF50));
        btnExportCSV.setForeground(Color.WHITE);
        btnExportCSV.addActionListener(e -> exportToCSV());
        exportPanel.add(btnExportCSV);
        
        JButton btnExportHTML = new JButton("📄 Exportar HTML");
        btnExportHTML.setBackground(new Color(0xFF9800));
        btnExportHTML.setForeground(Color.WHITE);
        btnExportHTML.addActionListener(e -> exportToHTML());
        exportPanel.add(btnExportHTML);
        
        JButton btnExportAll = new JButton("📦 Exportar Tudo");
        btnExportAll.setBackground(new Color(0x2196F3));
        btnExportAll.setForeground(Color.WHITE);
        btnExportAll.addActionListener(e -> exportAllFormats());
        exportPanel.add(btnExportAll);

        // Stats Info
        statsLabel = new JLabel("Carregando estatísticas...");
        statsLabel.setForeground(Color.WHITE);
        statsLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        statsLabel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        mainPanel.add(statsLabel, BorderLayout.SOUTH);
        mainPanel.add(exportPanel, BorderLayout.SOUTH);

        // Table
        rankingTable = new JTable();
        rankingTable.setBackground(new Color(0x1a1a2e));
        rankingTable.setForeground(Color.WHITE);
        rankingTable.setGridColor(TetrisColors.getAccent());
        rankingTable.setRowHeight(25);
        rankingTable.setFont(new Font("Arial", Font.PLAIN, 12));
        rankingTable.getTableHeader().setBackground(TetrisColors.getAccent());
        rankingTable.getTableHeader().setForeground(Color.WHITE);
        rankingTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 12));

        JScrollPane scrollPane = new JScrollPane(rankingTable);
        scrollPane.setBackground(TetrisColors.getBgDark());
        scrollPane.getViewport().setBackground(new Color(0x1a1a2e));
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        setContentPane(mainPanel);
        loadRanking();
    }

    private void loadRanking() {
        String difficulty = getDifficultyValue();
        ResultSet rs = DatabaseManager.getTop10(difficulty);

        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Posição");
        model.addColumn("Jogador");
        model.addColumn("Pontuação");
        model.addColumn("Nível");
        model.addColumn("Linhas");
        model.addColumn("Novo Record");
        model.addColumn("Data");

        int position = 1;
        int totalJogadores = 0;
        int totalPontos = 0;

        try {
            if (rs != null) {
                while (rs.next()) {
                    totalJogadores++;
                    int pontuacao = rs.getInt("Pontuacao");
                    totalPontos += pontuacao;
                    boolean novoRecord = rs.getBoolean("SuprouRecord");

                    model.addRow(new Object[]{
                            position++,
                            rs.getString("Username"),
                            String.format("%,d", pontuacao),
                            rs.getInt("Nivel"),
                            rs.getInt("Linhas"),
                            novoRecord ? "✓ SIM" : "✗ NÃO",
                            rs.getString("DataPartida")
                    });
                }
            }
        } catch (SQLException e) {
            System.err.println("Erro ao carregar ranking: " + e.getMessage());
        }

        rankingTable.setModel(model);

        // Atualizar stats
        String stats = String.format("Total de Jogadores: %d | Total de Pontos Registrados: %,d", totalJogadores, totalPontos);
        statsLabel.setText(stats);
    }

    private String getDifficultyValue() {
        String selected = (String) difficultyCombo.getSelectedItem();
        switch (selected) {
            case "Fácil": return "Fácil";
            case "Normal": return "Normal";
            case "Difícil": return "Difícil";
            case "Hardcore": return "Hardcore";
            default: return "Normal";
        }
    }

        private void exportToCSV() {
            String difficulty = getDifficultyValue();
            String fileName = "ranking_" + difficulty.toLowerCase() + ".csv";
            ExportManager.exportRankingToCSV(difficulty, fileName);
            JOptionPane.showMessageDialog(this, "✓ Ranking exportado para: " + fileName, "Sucesso", JOptionPane.INFORMATION_MESSAGE);
        }

        private void exportToHTML() {
            String difficulty = getDifficultyValue();
            String fileName = "ranking_" + difficulty.toLowerCase() + ".html";
            ExportManager.exportRankingToHTML(difficulty, fileName);
            JOptionPane.showMessageDialog(this, "✓ Ranking exportado para: " + fileName, "Sucesso", JOptionPane.INFORMATION_MESSAGE);
        }

        private void exportAllFormats() {
            String outputDir = ".";
            ExportManager.exportAllDifficulties(outputDir);
            JOptionPane.showMessageDialog(this, "✓ Todos os rankings foram exportados!\nCSV e HTML salvos em: " + outputDir, "Sucesso", JOptionPane.INFORMATION_MESSAGE);
        }
}
