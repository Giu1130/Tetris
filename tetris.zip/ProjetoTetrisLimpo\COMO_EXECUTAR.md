# 🚀 Como Executar o TETRIS

## ⚙️ Pré-requisitos

### Obrigatório:
- **Java 21 LTS** instalado
  - Download: https://adoptium.net/ (Temurin)
  - Ou: https://www.oracle.com/java/technologies/downloads/#java21
  - Verificar: `java -version` (deve mostrar "21.x.x")

### Opcional:
- Maven 3.9+ (para compilar)
  - Download: https://maven.apache.org/download.cgi

---

## 🎮 Executar o Jogo

### Método 1: JAR Pré-compilado (Mais Simples) ✅

```powershell
cd "C:\Users\Giulia Barros\Downloads\ProjetoTetrisLimpo"
java -jar target/ProjetoTetrisLimpo-1.0-SNAPSHOT.jar
```

**Vantagem**: Rápido, não precisa compilar
**Tempo**: ~2 segundos para iniciar

---

### Método 2: Maven Exec (Com Recompilação)

```powershell
cd "C:\Users\Giulia Barros\Downloads\ProjetoTetrisLimpo"
mvn clean compile exec:java -Dexec.mainClass="tetris.Main"
```

**Vantagem**: Garante versão mais recente do código
**Tempo**: ~5 segundos (inclui compilação)

---

### Método 3: Compilar e Correr Manualmente

```powershell
# Compilar
cd "C:\Users\Giulia Barros\Downloads\ProjetoTetrisLimpo"
mvn clean package -DskipTests

# Executar
java -jar target/ProjetoTetrisLimpo-1.0-SNAPSHOT.jar
```

**Vantagem**: Total controle
**Tempo**: ~5 segundos (inclui testes)

---

## 🎮 Tela Inicial

Ao iniciar, você verá:

1. **Dialog de Nome**: Digite seu nome para começar
   - Padrão: "Jogador" (se deixar em branco)
   - Clique "Começar" ou pressione ENTER

2. **Tela Principal**:
   - Esquerda: Hold + Score (pontos, nível, linhas, tempo)
   - Centro: Tabuleiro 10x20 com próximas peças
   - Direita: Fila de 5 peças

---

## ⌨️ Controles do Jogo

```
Movimento:
  ← →      : Mover peça esquerda/direita
  ↓        : Soft Drop (desce lentamente - 1 ponto/célula)
  SPACE    : Hard Drop (desce rápido - 2 pontos/célula)

Ações:
  Z / X    : Rotacionar peça (CW / CCW)
  C        : Hold (segura peça para depois)
  P        : Pausar / Resumir
  R        : Reiniciar partida

Menu:
  Botão "Ranking" : Ver Top 10 (durante o jogo)
```

---

## 🎨 Interface

### Painel Superior:
- **Combo Dificuldade**: Fácil (1.4x) / Normal (1.0x) / Difícil (0.7x)
- **Combo Tema**: Clássico / Neon / Escuro / Retrô
- **Botões**: Pausar, Reiniciar, Ranking

### Painel Esquerdo:
- **Hold**: Peça que você segurou
- **Score**: Pontos, Nível, Linhas, Tempo

### Painel Central:
- **Game Board**: 10 colunas × 20 linhas
- **Ghost Piece**: Preview translúcido (peça que está caindo)
- **Pause Overlay**: Mostra quando pausado

### Painel Direito:
- **Next Pieces**: Próximas 5 peças na fila

---

## 🎯 Objetivo & Pontuação

**Objetivo**: Completar linhas horizontais

**Pontuação Clássica Tetris**:
```
1 linha:  40  × nível
2 linhas: 100 × nível
3 linhas: 300 × nível
4 linhas: 1200× nível (Tetris!)

Extra:
- Soft Drop: +1 ponto por célula
- Hard Drop: +2 pontos por célula

Nível sobe a cada 10 linhas completas
Velocidade aumenta com o nível
```

---

## 🏆 Ranking

### Visualizar:
- Clique no botão "Ranking" durante o jogo
- Mostra Top 10 jogadores

### Novo Score:
- Ao terminar, seu score é **automaticamente salvo**
- Se for Top 10, você sobe no ranking
- Arquivo: `ranking.txt` (na pasta do projeto)

### Dados Salvos:
- Nome do jogador
- Pontuação final
- Nível alcançado
- Linhas completadas
- Dificuldade
- Timestamp

---

## 🎨 Temas Disponíveis

Mude o tema a qualquer momento com a combo durante o jogo!

### Clássico (Padrão)
- Cor: Vermelho vibrante + Azul escuro
- Estilo: NES Tetris original

### Neon
- Cor: Magenta + Ciano em fundo preto
- Estilo: Futurista/80s

### Escuro
- Cor: Verde + Cinza
- Estilo: Profissional/Moderno

### Retrô
- Cor: Laranja + Tons vintage
- Estilo: Clássico/Acessível

---

## 🐛 Troubleshooting

### ❌ Erro: "java: command not found"
**Solução**: 
```powershell
# Verificar se Java está instalado
java -version

# Se não estiver, instale do:
https://adoptium.net/
```

### ❌ Erro: "No main manifest attribute"
**Solução**: Use o JAR correto
```powershell
java -jar target/ProjetoTetrisLimpo-1.0-SNAPSHOT.jar
```

### ❌ Jogo lento/travando
**Solução**: 
- Feche outros programas
- Aumente a dificuldade se for muito fácil
- Reinicie o jogo (tecla R)

### ❌ GIFs não carregam
**Solução**: Verifique conexão com internet (GIFs são do Tenor)

---

## 📊 Status do Build

Última compilação bem-sucedida:

```
✅ 22 arquivos Java compilados
✅ Release: Java 21
✅ Tempo: 3.098 segundos
✅ JAR: 45 KB
✅ Status: BUILD SUCCESS
```

---

## 🎉 Pronto para Jogar!

```
   ████████████████████████████
   █  TETRIS - Java 21 LTS  █
   █  Boa Sorte! 🎮        █
   ████████████████████████████
```

**Digite seu nome e comece a jogar!**

*Com GIFs de celebração do Cellbit inclusos! 🎉*

---

**Dúvidas?** Abra uma issue ou entre em contato!

**Versão**: 1.0-SNAPSHOT | **Data**: Novembro 2025 | **Status**: ✅ Pronto
