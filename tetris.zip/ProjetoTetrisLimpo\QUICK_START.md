# ⚡ QUICK START - TETRIS v3.0

## 🚀 Iniciar em 10 Segundos

```powershell
# Abra PowerShell na pasta do projeto
cd "C:\Users\Giulia Barros\Downloads\ProjetoTetrisLimpo"

# Execute
java -jar target/ProjetoTetrisLimpo-1.0-SNAPSHOT.jar
```

**PRONTO!** 🎮

---

## 📦 Build Necessário? (Primeira Vez)

Se for primeira vez ou fez mudanças:

```powershell
# Recompilar e empacotar
mvn clean package -DskipTests

# Depois executar
java -jar target/ProjetoTetrisLimpo-1.0-SNAPSHOT.jar
```

---

## ⌨️ Controles Básicos

| Ação | Tecla |
|------|-------|
| Mover Esquerda | ← |
| Mover Direita | → |
| Girar | ↑ |
| Cair Rápido | ↓ |
| Hard Drop | SPACE |
| Hold Peça | C |
| Pausar | P |
| Reiniciar | R |

---

## 🎯 O Que Mudou em v3.0

✅ **GIF Poggers** - Quando sobe de rank  
✅ **GIF Sad** - Quando perde  
✅ **Combo Box Corrigido** - Setinhas funcionam  
✅ **Fonte Corrigida** - Sem emojis bugged  
✅ **Logo PNG** - No login (opcional)  
✅ **Ícone App** - Na barra de tarefas (opcional)

---

## 🖼️ Adicionar Imagens (Opcional)

1. Coloque em `src/main/resources/`:
   - `tetris_logo.png` (250x150px)
   - `tetris_icon.png` (32x32px)

2. Recompile:
```powershell
mvn clean package -DskipTests
java -jar target/ProjetoTetrisLimpo-1.0-SNAPSHOT.jar
```

**Sem imagens?** Funciona normal com fallback! ✅

---

## 🧪 Teste Rápido - Bug Fix

**CRÍTICO**: Verificar se combo box funciona:

1. Abra o jogo
2. **Clique em "Dificuldade: [Normal ▼]"**
3. **Aperte SETA ESQUERDA/DIREITA**
4. ✅ Peça deve mover (NÃO o combo abrir)

Se funcionar → **Bug CORRIGIDO!** 🎉

---

## 🎬 Teste GIFs

### Novo Record (Top 10)
1. Jogue e consiga >5000 pontos
2. **RESULTADO**: "NOVO RECORD!" (OURO) + GIF Poggers

### Perde
1. Jogue com score baixo
2. **RESULTADO**: "GAME OVER" (VERMELHO) + GIF Sad

### Melhora Posição  
1. Jogue 2x com MESMO NOME
2. Segundo jogo: Score melhor
3. **RESULTADO**: "MELHOROU DE RANK!" (VERDE) + GIF Poggers

---

## 📁 Estrutura Projeto

```
ProjetoTetrisLimpo/
├── src/main/java/tetris/
│   ├── Main.java
│   ├── domain/ (Lógica)
│   ├── engine/ (Input)
│   ├── ui/     (Visual)
│   └── util/   (Utils + ImageLoader)
├── target/
│   └── ProjetoTetrisLimpo-1.0-SNAPSHOT.jar
├── pom.xml
└── docs/ (Documentação)
```

---

## 🐛 Se Algo Falhar

```powershell
# Limpar tudo e recompilar
mvn clean compile -DskipTests
mvn package -DskipTests

# Se erro de Java version
java -version

# Se não encontrar Maven
mvn --version
```

---

## ✨ Features

- 🎮 Tetris completo com 7 peças
- 🎨 4 temas de cor
- 🎯 Sistema de pontuação e níveis
- 🏆 Ranking automático (Top 10)
- 🎬 GIFs do Cellbit (Poggers/Sad)
- 🖼️ Suporte a PNG
- ⚙️ Menu com opções
- 📱 Interface moderna
- ✅ Sem bugs críticos

---

## 📊 Requisitos

- ✅ Java 21 LTS (já instalado?)
- ✅ Maven 3.9+ (já instalado?)
- ✅ Conexão internet (para carregar GIFs)

---

**Pronto para jogar! 🚀**

```
java -jar target/ProjetoTetrisLimpo-1.0-SNAPSHOT.jar
```