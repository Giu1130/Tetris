package tetris.ui;

import javax.swing.*;
import java.awt.*;

public class PlayerNameDialog extends JDialog {
    private JTextField nameField;
    private String playerName = null;
    private boolean confirmed = false;

    public PlayerNameDialog(JFrame parent) {
        super(parent, "TETRIS - Bem-vindo(a)!", true);
        setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
        setResizable(false);
        initComponents();
        setLocationRelativeTo(parent);
    }

    private void initComponents() {
        JPanel mainPanel = new JPanel();
        mainPanel.setBackground(TetrisColors.getBgDark());
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 40, 40, 40));

        // Logo/Title - Tentar carregar imagem, se não houver usar texto
        javax.swing.ImageIcon tetrisLogo = tetris.util.ImageLoader.getTetrisLogo();
        if (tetrisLogo != null) {
            JLabel logoLabel = new JLabel(tetrisLogo);
            logoLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
            mainPanel.add(logoLabel);
            mainPanel.add(Box.createVerticalStrut(15));
        } else {
            // Fallback para texto
            JLabel logoLabel = new JLabel("TETRIS");
            logoLabel.setFont(new Font("Arial", Font.BOLD, 48));
            logoLabel.setForeground(TetrisColors.getAccent());
            logoLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
            mainPanel.add(logoLabel);
            mainPanel.add(Box.createVerticalStrut(10));
        }

        JLabel subtitleLabel = new JLabel("Digite seu nome para começar");
        subtitleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        subtitleLabel.setForeground(TetrisColors.getTextSecondary());
        subtitleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(subtitleLabel);
        mainPanel.add(Box.createVerticalStrut(30));

        // Input Label
        JLabel inputLabel = new JLabel("Nome do Jogador:");
        inputLabel.setFont(new Font("Arial", Font.BOLD, 14));
        inputLabel.setForeground(TetrisColors.getTextPrimary());
        inputLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(inputLabel);
        mainPanel.add(Box.createVerticalStrut(8));

        nameField = new JTextField(20);
        nameField.setFont(new Font("Courier New", Font.PLAIN, 16));
        nameField.setMaximumSize(new Dimension(350, 45));
        nameField.setAlignmentX(Component.CENTER_ALIGNMENT);
        nameField.setBackground(TetrisColors.getBgMedium());
        nameField.setForeground(TetrisColors.getTextPrimary());
        nameField.setCaretColor(TetrisColors.getAccent());
        nameField.setBorder(BorderFactory.createLineBorder(TetrisColors.getAccent(), 2));
        mainPanel.add(nameField);
        mainPanel.add(Box.createVerticalStrut(40));

        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(TetrisColors.getBgDark());
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 15, 0));

        JButton okButton = new JButton("Começar");
        okButton.setFont(new Font("Arial", Font.BOLD, 14));
        okButton.setBackground(TetrisColors.getAccent());
        okButton.setForeground(Color.WHITE);
        okButton.setFocusPainted(false);
        okButton.setPreferredSize(new Dimension(150, 45));
        okButton.addActionListener(e -> onOK());
        buttonPanel.add(okButton);

        JButton cancelButton = new JButton("Sair");
        cancelButton.setFont(new Font("Arial", Font.BOLD, 14));
        cancelButton.setBackground(new Color(0x555555));
        cancelButton.setForeground(Color.WHITE);
        cancelButton.setFocusPainted(false);
        cancelButton.setPreferredSize(new Dimension(150, 45));
        cancelButton.addActionListener(e -> onCancel());
        buttonPanel.add(cancelButton);

        buttonPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 60));
        buttonPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(buttonPanel);

        setContentPane(mainPanel);
        setSize(550, 400);
        
        nameField.addActionListener(e -> onOK());
        nameField.requestFocus();
    }

    private void onOK() {
        playerName = nameField.getText().trim();
        if (playerName.isEmpty()) {
            playerName = "Jogador";
        }
        confirmed = true;
        setVisible(false);
        dispose();
    }

    private void onCancel() {
        playerName = null;
        confirmed = false;
        setVisible(false);
        dispose();
    }

    public String getPlayerName() {
        return playerName;
    }

    public boolean isConfirmed() {
        return confirmed;
    }
}
