package tetris.domain;
public class Jogador {
    private final String nome;
    public Jogador(String nome){ this.nome = nome; }
    public String getNome(){ return nome; }
}
    