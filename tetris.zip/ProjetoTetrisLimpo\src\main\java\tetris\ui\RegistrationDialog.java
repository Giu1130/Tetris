package tetris.ui;

import tetris.util.AuthManager;

import javax.swing.*;
import java.awt.*;

public class RegistrationDialog extends JDialog {
    private final AuthManager auth;
    private JTextField userField;
    private JPasswordField passField;
    private JPasswordField confirmField;

    public RegistrationDialog(JFrame parent, AuthManager auth) {
        super(parent, "Registrar - TETRIS", true);
        this.auth = auth;
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        setResizable(false);
        initComponents();
        setLocationRelativeTo(parent);
    }

    private void initComponents() {
        JPanel main = new JPanel();
        main.setBackground(TetrisColors.getBgDark());
        main.setLayout(new BoxLayout(main, BoxLayout.Y_AXIS));
        main.setBorder(BorderFactory.createEmptyBorder(20,20,20,20));

        JLabel lbl = new JLabel("Criar nova conta");
        lbl.setFont(new Font("Arial", Font.BOLD, 20));
        lbl.setForeground(TetrisColors.getAccent());
        lbl.setAlignmentX(Component.CENTER_ALIGNMENT);
        main.add(lbl);
        main.add(Box.createVerticalStrut(10));

        userField = new JTextField(20);
        userField.setMaximumSize(new Dimension(300,35));
        userField.setBorder(BorderFactory.createTitledBorder("Usuário"));
        main.add(userField);
        main.add(Box.createVerticalStrut(8));

        passField = new JPasswordField(20);
        passField.setMaximumSize(new Dimension(300,35));
        passField.setBorder(BorderFactory.createTitledBorder("Senha"));
        main.add(passField);
        main.add(Box.createVerticalStrut(8));

        confirmField = new JPasswordField(20);
        confirmField.setMaximumSize(new Dimension(300,35));
        confirmField.setBorder(BorderFactory.createTitledBorder("Confirmar senha"));
        main.add(confirmField);
        main.add(Box.createVerticalStrut(12));

        JPanel btns = new JPanel(new FlowLayout(FlowLayout.CENTER, 10,0));
        btns.setBackground(TetrisColors.getBgDark());
        JButton create = new JButton("Criar");
        create.setBackground(TetrisColors.getAccent());
        create.setForeground(Color.WHITE);
        create.addActionListener(e -> onCreate());
        JButton cancel = new JButton("Cancelar");
        cancel.setBackground(new Color(0x777777));
        cancel.setForeground(Color.WHITE);
        cancel.addActionListener(e -> dispose());
        btns.add(create); btns.add(cancel);

        main.add(btns);
        setContentPane(main);
        setSize(420, 300);
    }

    private void onCreate() {
        String user = userField.getText().trim();
        String pass = new String(passField.getPassword());
        String conf = new String(confirmField.getPassword());
        if (user.isEmpty() || pass.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Informe usuário e senha.", "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (!pass.equals(conf)) {
            JOptionPane.showMessageDialog(this, "As senhas não coincidem.", "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (auth.userExists(user)) {
            JOptionPane.showMessageDialog(this, "Usuário já existe.", "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }
        boolean ok = auth.register(user, pass);
        if (ok) {
            JOptionPane.showMessageDialog(this, "Registro criado com sucesso. Faça login.", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Erro ao criar conta.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
}
